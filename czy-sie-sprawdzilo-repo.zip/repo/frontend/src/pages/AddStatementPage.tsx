import { Link } from "react-router-dom";
import { usePoliticians } from "../hooks/useApi";
import { useAddStatement } from "../hooks/useAddStatement";
import { fullName } from "../lib/format";
import { KIND_LABELS, KINDS } from "../lib/labels";

function FieldError({ id, message }: { id: string; message?: string }) {
  return message ? (
    <span id={id} className="field-error" role="alert">
      {message}
    </span>
  ) : null;
}

export function AddStatementPage() {
  const politicians = usePoliticians("");
  const form = useAddStatement(politicians.reload);
  const { draft, errors } = form;

  if (form.created) {
    return (
      <div className="state" role="status">
        <h1>Dodano wypowiedź</h1>
        <p>Zapisano {form.created.predictions.length} predykcji. Czekają na weryfikację.</p>
        <p>
          <Link to="/">Zobacz listę</Link> · <button type="button" className="btn btn-link" onClick={form.reset}>Dodaj kolejną</button>
        </p>
      </div>
    );
  }

  const err = (key: string) => (errors[key] ? `${key.replace(/\./g, "-")}-err` : undefined);

  return (
    <>
      <h1>Dodaj wypowiedź</h1>
      <form
        className="form"
        noValidate
        onSubmit={(e) => {
          e.preventDefault();
          void form.submit();
        }}
      >
        <fieldset>
          <legend>Polityk</legend>
          <div className="radio-row">
            <label>
              <input type="radio" name="mode" checked={draft.politicianMode === "existing"} onChange={() => form.setField("politicianMode", "existing")} /> Z listy
            </label>
            <label>
              <input type="radio" name="mode" checked={draft.politicianMode === "new"} onChange={() => form.setField("politicianMode", "new")} /> Nowy
            </label>
          </div>

          {draft.politicianMode === "existing" ? (
            <label className="field">
              <span>Wybierz polityka</span>
              <select
                value={draft.politicianId}
                aria-invalid={Boolean(errors.politicianId)}
                aria-describedby={err("politicianId")}
                onChange={(e) => form.setField("politicianId", e.target.value)}
              >
                <option value="">— wybierz —</option>
                {(politicians.data ?? []).map((p) => (
                  <option key={p.id} value={p.id}>
                    {fullName(p)}
                    {p.party ? ` (${p.party})` : ""}
                  </option>
                ))}
              </select>
              <FieldError id="politicianId-err" message={errors.politicianId} />
            </label>
          ) : (
            <div className="filter-grid">
              <label className="field">
                <span>Imię</span>
                <input value={draft.newFirstName} aria-invalid={Boolean(errors.newFirstName)} aria-describedby={err("newFirstName")} onChange={(e) => form.setField("newFirstName", e.target.value)} />
                <FieldError id="newFirstName-err" message={errors.newFirstName} />
              </label>
              <label className="field">
                <span>Nazwisko</span>
                <input value={draft.newLastName} aria-invalid={Boolean(errors.newLastName)} aria-describedby={err("newLastName")} onChange={(e) => form.setField("newLastName", e.target.value)} />
                <FieldError id="newLastName-err" message={errors.newLastName} />
              </label>
              <label className="field">
                <span>Partia (opcjonalnie)</span>
                <input value={draft.newParty} onChange={(e) => form.setField("newParty", e.target.value)} />
              </label>
            </div>
          )}
        </fieldset>

        <fieldset>
          <legend>Wypowiedź</legend>
          <label className="field">
            <span>Cytat (dosłowny)</span>
            <textarea rows={4} value={draft.text} aria-invalid={Boolean(errors.text)} aria-describedby={err("text")} onChange={(e) => form.setField("text", e.target.value)} />
            <FieldError id="text-err" message={errors.text} />
          </label>
          <div className="filter-grid">
            <label className="field">
              <span>Link do źródła</span>
              <input type="url" inputMode="url" placeholder="https://" value={draft.sourceUrl} aria-invalid={Boolean(errors.sourceUrl)} aria-describedby={err("sourceUrl")} onChange={(e) => form.setField("sourceUrl", e.target.value)} />
              <FieldError id="sourceUrl-err" message={errors.sourceUrl} />
            </label>
            <label className="field">
              <span>Data wypowiedzi</span>
              <input type="date" value={draft.statementDate} aria-invalid={Boolean(errors.statementDate)} aria-describedby={err("statementDate")} onChange={(e) => form.setField("statementDate", e.target.value)} />
              <FieldError id="statementDate-err" message={errors.statementDate} />
            </label>
          </div>
        </fieldset>

        {draft.predictions.map((p, i) => (
          <fieldset key={p.key}>
            <legend>Predykcja {i + 1}</legend>
            <label className="field">
              <span>Co przewidziano lub obiecano</span>
              <input value={p.claim} aria-invalid={Boolean(errors[`predictions.${i}.claim`])} aria-describedby={err(`predictions.${i}.claim`)} onChange={(e) => form.updatePrediction(i, "claim", e.target.value)} />
              <FieldError id={`predictions-${i}-claim-err`} message={errors[`predictions.${i}.claim`]} />
            </label>
            <label className="field">
              <span>Mierzalny warunek (opcjonalnie)</span>
              <input value={p.condition} placeholder="np. CPI r/r w grudniu >= 8%" onChange={(e) => form.updatePrediction(i, "condition", e.target.value)} />
            </label>
            <div className="filter-grid">
              <label className="field">
                <span>Rodzaj</span>
                <select value={p.kind} onChange={(e) => form.updatePrediction(i, "kind", e.target.value as typeof p.kind)}>
                  {KINDS.map((k) => (
                    <option key={k} value={k}>
                      {KIND_LABELS[k]}
                    </option>
                  ))}
                </select>
              </label>
              <label className="field">
                <span>Temat (opcjonalnie)</span>
                <input value={p.topic} onChange={(e) => form.updatePrediction(i, "topic", e.target.value)} />
              </label>
              <label className="field">
                <span>Termin (opcjonalnie)</span>
                <input type="date" value={p.deadline} aria-invalid={Boolean(errors[`predictions.${i}.deadline`])} aria-describedby={err(`predictions.${i}.deadline`)} onChange={(e) => form.updatePrediction(i, "deadline", e.target.value)} />
                <FieldError id={`predictions-${i}-deadline-err`} message={errors[`predictions.${i}.deadline`]} />
              </label>
            </div>
            {draft.predictions.length > 1 && (
              <button type="button" className="btn btn-link" onClick={() => form.removePrediction(i)}>
                Usuń predykcję {i + 1}
              </button>
            )}
          </fieldset>
        ))}

        <button type="button" className="btn" onClick={form.addPrediction}>
          + Dodaj kolejną predykcję
        </button>

        {form.serverError && (
          <p className="state state-error" role="alert">
            {form.serverError}
          </p>
        )}
        {Object.keys(errors).length > 0 && (
          <p className="field-error" role="alert">
            Popraw zaznaczone pola.
          </p>
        )}
        <button type="submit" className="btn btn-primary" disabled={form.submitting}>
          {form.submitting ? "Zapisywanie…" : "Zapisz wypowiedź"}
        </button>
      </form>
    </>
  );
}
