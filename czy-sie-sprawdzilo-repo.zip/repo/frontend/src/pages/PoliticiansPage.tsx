import { useState } from "react";
import { Link } from "react-router-dom";
import { useDebouncedValue } from "../hooks/useDebouncedValue";
import { usePoliticians } from "../hooks/useApi";
import { formatPercent, fullName, pluralize } from "../lib/format";
import { accuracyOf } from "../lib/stats";
import { EmptyState, ErrorState, LoadingState } from "../ui/States";

export function PoliticiansPage() {
  const [q, setQ] = useState("");
  const debounced = useDebouncedValue(q, 300);
  const { data, error, loading, reload } = usePoliticians(debounced);

  return (
    <>
      <h1>Politycy</h1>
      <form className="filters" role="search" onSubmit={(e) => e.preventDefault()}>
        <label className="field">
          <span>Szukaj polityka</span>
          <input type="search" value={q} placeholder="imię lub nazwisko" onChange={(e) => setQ(e.target.value)} />
        </label>
      </form>

      {error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : !data ? (
        <LoadingState />
      ) : data.length === 0 ? (
        <EmptyState>
          <p>Nie znaleziono polityka.</p>
        </EmptyState>
      ) : (
        <ul className="people" aria-busy={loading}>
          {data.map((p) => (
            <li key={p.id} className="card">
              <h2 className="h3">
                <Link to={`/politycy/${p.slug}`}>{fullName(p)}</Link>
              </h2>
              <p className="muted">{p.party ?? "bez partii"}</p>
              <p>
                Trafność: <strong>{formatPercent(accuracyOf(p.stats))}</strong>{" "}
                <span className="muted small">
                  ({p.stats.total} {pluralize(p.stats.total, "predykcja", "predykcje", "predykcji")}, rozstrzygniętych: {p.stats.resolved})
                </span>
              </p>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
