import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useDebouncedValue } from "../hooks/useDebouncedValue";
import { useMeta, usePredictions } from "../hooks/useApi";
import { DEFAULT_FILTERS, hasActiveFilters, parseFilters, serializeFilters, type PredictionFilters } from "../lib/query";
import { FilterBar } from "../ui/FilterBar";
import { PredictionList } from "../ui/PredictionList";

export function PredictionsPage() {
  const [params, setParams] = useSearchParams();
  const filters = useMemo(() => parseFilters(params), [params]);

  const update = (patch: Partial<PredictionFilters>) => {
    // zmiana filtra wraca na pierwszą stronę, chyba że zmieniamy samą stronę
    const next = { ...filters, page: 1, ...patch };
    setParams(serializeFilters(next), { replace: true });
  };

  // Pole wyszukiwania: lokalny stan + debounce -> URL
  const [search, setSearch] = useState(filters.q);
  const debouncedSearch = useDebouncedValue(search, 300);
  useEffect(() => {
    if (debouncedSearch !== filters.q) update({ q: debouncedSearch });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch]);

  const meta = useMeta();
  const result = usePredictions(filters);

  return (
    <>
      <h1>Czy się sprawdziło?</h1>
      <p className="lead">Wypowiedzi i obietnice polityków sprawdzane po fakcie.</p>
      <FilterBar
        filters={filters}
        meta={meta.data}
        searchValue={search}
        onSearchChange={setSearch}
        onChange={update}
        canReset={hasActiveFilters(filters) || search !== ""}
        onReset={() => {
          setSearch("");
          setParams(serializeFilters({ ...DEFAULT_FILTERS, sort: filters.sort }), { replace: true });
        }}
      />
      <PredictionList
        result={result}
        page={filters.page}
        onPageChange={(page) => {
          update({ page });
          window.scrollTo({ top: 0 });
        }}
        emptyHint="Spróbuj zmienić wyszukiwaną frazę lub wyczyścić filtry."
      />
    </>
  );
}
