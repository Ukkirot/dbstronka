import { useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ApiError } from "../api/http";
import { usePolitician, usePredictions } from "../hooks/useApi";
import { formatPercent, fullName } from "../lib/format";
import { STATUS_LABELS, STATUSES } from "../lib/labels";
import { DEFAULT_FILTERS, type PredictionFilters } from "../lib/query";
import { accuracyOf } from "../lib/stats";
import { PredictionList } from "../ui/PredictionList";
import { ProportionBar } from "../ui/ProportionBar";
import { ErrorState, LoadingState } from "../ui/States";
import { NotFoundPage } from "./NotFoundPage";

export function PoliticianPage() {
  const { slug = "" } = useParams();
  const politician = usePolitician(slug);

  if (politician.error) {
    return politician.error instanceof ApiError && politician.error.status === 404 ? (
      <NotFoundPage />
    ) : (
      <ErrorState error={politician.error} onRetry={politician.reload} />
    );
  }
  if (!politician.data) return <LoadingState />;

  const p = politician.data;
  const accuracy = accuracyOf(p.stats);

  return (
    <>
      <p>
        <Link to="/politycy">← Wszyscy politycy</Link>
      </p>
      <h1>{fullName(p)}</h1>
      <p className="muted">{p.party ?? "bez partii"}</p>

      <section className="card" aria-label="Statystyka trafności">
        <p className="big-number" aria-label={`Trafność ${formatPercent(accuracy)}`}>
          {formatPercent(accuracy)}
        </p>
        <p className="muted small">
          trafność = (sprawdziło się + ½ częściowo) / rozstrzygnięte · rozstrzygniętych: {p.stats.resolved} z {p.stats.total}
        </p>
        <ProportionBar stats={p.stats} />
      </section>

      <h2>Predykcje</h2>
      <PoliticianPredictions politicianId={p.id} />
    </>
  );
}

function PoliticianPredictions({ politicianId }: { politicianId: number }) {
  const [status, setStatus] = useState<PredictionFilters["status"]>("");
  const [page, setPage] = useState(1);
  const filters = useMemo<PredictionFilters>(
    () => ({ ...DEFAULT_FILTERS, status, page, politicianId }),
    [status, page, politicianId],
  );
  const result = usePredictions(filters);

  return (
    <>
      <label className="field field-inline">
        <span>Status</span>
        <select
          value={status}
          onChange={(e) => {
            setStatus(e.target.value as PredictionFilters["status"]);
            setPage(1);
          }}
        >
          <option value="">Wszystkie</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {STATUS_LABELS[s]}
            </option>
          ))}
        </select>
      </label>
      <PredictionList result={result} page={page} onPageChange={setPage} />
    </>
  );
}
