import { Link } from "react-router-dom";

export function NotFoundPage() {
  return (
    <div className="state">
      <h1>Nie znaleziono strony</h1>
      <p>
        <Link to="/">Wróć do listy predykcji</Link>
      </p>
    </div>
  );
}
