/**
 * Typy odpowiadające schematom OpenAPI backendu.
 *
 * Ten plik jest startowym odpowiednikiem tego, co wygeneruje:
 *     npm run gen:api     (backend musi działać na http://localhost:8000)
 * Po uruchomieniu komendy plik zostanie nadpisany prawdziwym wynikiem
 * openapi-typescript – nazwy schematów (PredictionOut itd.) są te same.
 */
export interface components {
  schemas: {
    PoliticianStats: {
      true: number;
      false: number;
      partial: number;
      unverifiable: number;
      pending: number;
      total: number;
      resolved: number;
      accuracy: number | null;
    };
    PoliticianBrief: {
      id: number;
      first_name: string;
      last_name: string;
      party: string | null;
      slug: string;
    };
    PoliticianOut: components["schemas"]["PoliticianBrief"] & {
      created_at: string;
      stats: components["schemas"]["PoliticianStats"];
    };
    PoliticianCreate: {
      first_name: string;
      last_name: string;
      party?: string | null;
      slug?: string | null;
    };
    StatementBrief: {
      id: number;
      text: string;
      source_url: string;
      statement_date: string;
    };
    PredictionInline: {
      kind?: "prediction" | "promise";
      claim: string;
      condition?: string | null;
      topic?: string | null;
      deadline?: string | null;
    };
    PredictionBrief: {
      id: number;
      statement_id: number;
      kind: "prediction" | "promise";
      claim: string;
      condition: string | null;
      topic: string | null;
      deadline: string | null;
      created_at: string;
    };
    StatementCreate: {
      politician_id: number;
      text: string;
      source_url: string;
      statement_date: string;
      predictions?: components["schemas"]["PredictionInline"][];
    };
    StatementOut: components["schemas"]["StatementBrief"] & {
      politician_id: number;
      created_at: string;
      predictions: components["schemas"]["PredictionBrief"][];
    };
    VerificationOut: {
      id: number;
      prediction_id: number;
      outcome: "true" | "false" | "partial" | "unverifiable";
      fulfilled_at: string | null;
      note: string | null;
      sources: string[];
      verified_by: "ai" | "human";
      verified_at: string;
    };
    PredictionOut: {
      id: number;
      statement_id: number;
      kind: "prediction" | "promise";
      claim: string;
      condition: string | null;
      topic: string | null;
      deadline: string | null;
      created_at: string;
      status: "true" | "false" | "partial" | "unverifiable" | "pending";
      statement: components["schemas"]["StatementBrief"];
      politician: components["schemas"]["PoliticianBrief"];
      verification: components["schemas"]["VerificationOut"] | null;
    };
    PredictionPage: {
      items: components["schemas"]["PredictionOut"][];
      total: number;
      limit: number;
      offset: number;
    };
    MetaOut: {
      parties: string[];
      topics: string[];
      statuses: ("true" | "false" | "partial" | "unverifiable" | "pending")[];
      kinds: ("prediction" | "promise")[];
    };
  };
}
