/** Jedyne miejsce, z którego reszta aplikacji importuje typy API. */
import type { components } from "./schema";

type S = components["schemas"];

export type Outcome = "true" | "false" | "partial" | "unverifiable";
export type Status = Outcome | "pending";
export type Kind = "prediction" | "promise";

export type PredictionOut = S["PredictionOut"];
export type PredictionPage = S["PredictionPage"];
export type VerificationOut = S["VerificationOut"];
export type PoliticianOut = S["PoliticianOut"];
export type PoliticianBrief = S["PoliticianBrief"];
export type PoliticianStats = S["PoliticianStats"];
export type PoliticianCreate = S["PoliticianCreate"];
export type StatementCreate = S["StatementCreate"];
export type StatementOut = S["StatementOut"];
export type PredictionInline = S["PredictionInline"];
export type MetaOut = S["MetaOut"];
