/** Minimalny klient HTTP. Używa tylko fetch/URLSearchParams/AbortSignal (dostępne też w React Native). */
import { API_BASE_URL } from "./config";

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    message: string,
    public readonly detail?: unknown,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

export type QueryValue = string | number | boolean | null | undefined;
export type Query = Record<string, QueryValue>;

let authToken: string | null = null;
/** Miejsce na przyszłą autoryzację – backend ma już nagłówek Authorization. */
export function setAuthToken(token: string | null): void {
  authToken = token;
}

export function isAbortError(error: unknown): boolean {
  return error instanceof Error && error.name === "AbortError";
}

export function buildUrl(path: string, query?: Query): string {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(query ?? {})) {
    if (value === undefined || value === null || value === "") continue;
    params.set(key, String(value));
  }
  const qs = params.toString();
  return `${API_BASE_URL}${path}${qs ? `?${qs}` : ""}`;
}

function messageFromDetail(detail: unknown, fallback: string): string {
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) {
    // błędy walidacji FastAPI: [{loc: [...], msg: "..."}]
    return detail
      .map((d) => {
        const field = Array.isArray(d?.loc) ? d.loc.filter((x: unknown) => x !== "body").join(".") : "";
        return field ? `${field}: ${d?.msg}` : String(d?.msg ?? "");
      })
      .join("; ");
  }
  return fallback;
}

export async function request<T>(
  path: string,
  options: { method?: string; query?: Query; body?: unknown; signal?: AbortSignal } = {},
): Promise<T> {
  const headers: Record<string, string> = { Accept: "application/json" };
  if (options.body !== undefined) headers["Content-Type"] = "application/json";
  if (authToken) headers.Authorization = `Bearer ${authToken}`;

  let response: Response;
  try {
    response = await fetch(buildUrl(path, options.query), {
      method: options.method ?? "GET",
      headers,
      body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
      signal: options.signal,
    });
  } catch (error) {
    if (isAbortError(error)) throw error;
    throw new ApiError(0, "Brak połączenia z serwerem. Sprawdź internet i spróbuj ponownie.");
  }

  if (!response.ok) {
    let detail: unknown;
    try {
      detail = (await response.json())?.detail;
    } catch {
      /* odpowiedź bez JSON-a */
    }
    throw new ApiError(
      response.status,
      messageFromDetail(detail, `Błąd serwera (${response.status}).`),
      detail,
    );
  }
  if (response.status === 204) return undefined as T;
  return (await response.json()) as T;
}
