/** Funkcje odpowiadające endpointom REST. Zero zależności od Reacta i przeglądarki. */
import { request } from "./http";
import type {
  Kind,
  MetaOut,
  PoliticianCreate,
  PoliticianOut,
  PredictionOut,
  PredictionPage,
  Status,
  StatementCreate,
  StatementOut,
} from "./types";

export type SortKey = "statement_date" | "deadline" | "verified_at" | "created_at";
export type SortOrder = "asc" | "desc";

export type PredictionQuery = {
  status?: Status;
  party?: string;
  topic?: string;
  politician_id?: number;
  kind?: Kind;
  q?: string;
  date_from?: string;
  date_to?: string;
  sort?: SortKey;
  order?: SortOrder;
  limit?: number;
  offset?: number;
};

export const listPredictions = (query: PredictionQuery, signal?: AbortSignal) =>
  request<PredictionPage>("/predictions", { query, signal });

export const getPrediction = (id: number, signal?: AbortSignal) =>
  request<PredictionOut>(`/predictions/${id}`, { signal });

export const listPoliticians = (query: { q?: string; party?: string } = {}, signal?: AbortSignal) =>
  request<PoliticianOut[]>("/politicians", { query: { ...query, limit: 200 }, signal });

export const getPolitician = (slug: string, signal?: AbortSignal) =>
  request<PoliticianOut>(`/politicians/${encodeURIComponent(slug)}`, { signal });

export const getMeta = (signal?: AbortSignal) => request<MetaOut>("/meta", { signal });

export const createPolitician = (body: PoliticianCreate) =>
  request<PoliticianOut>("/politicians", { method: "POST", body });

export const createStatement = (body: StatementCreate) =>
  request<StatementOut>("/statements", { method: "POST", body });
