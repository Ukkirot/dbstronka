/**
 * Konfiguracja zależna od platformy – JEDYNE miejsce z import.meta.env (Vite).
 * W React Native/Expo zamień na: process.env.EXPO_PUBLIC_API_URL.
 */
export const API_BASE_URL: string = import.meta.env.VITE_API_URL ?? "/api/v1";
