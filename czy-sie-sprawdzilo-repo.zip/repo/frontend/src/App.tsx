import { NavLink, Route, Routes } from "react-router-dom";
import { AddStatementPage } from "./pages/AddStatementPage";
import { NotFoundPage } from "./pages/NotFoundPage";
import { PoliticianPage } from "./pages/PoliticianPage";
import { PoliticiansPage } from "./pages/PoliticiansPage";
import { PredictionsPage } from "./pages/PredictionsPage";
import { ThemeToggle } from "./ui/ThemeToggle";

export function App() {
  return (
    <>
      <a className="skip-link" href="#content">
        Przejdź do treści
      </a>
      <header className="site-header">
        <div className="container header-inner">
          <NavLink to="/" className="brand">
            ✓ Czy się sprawdziło?
          </NavLink>
          <nav aria-label="Główna nawigacja">
            <NavLink to="/" end>Predykcje</NavLink>
            <NavLink to="/politycy">Politycy</NavLink>
            <NavLink to="/dodaj">Dodaj</NavLink>
          </nav>
          <ThemeToggle />
        </div>
      </header>
      <main id="content" className="container" tabIndex={-1}>
        <Routes>
          <Route path="/" element={<PredictionsPage />} />
          <Route path="/politycy" element={<PoliticiansPage />} />
          <Route path="/politycy/:slug" element={<PoliticianPage />} />
          <Route path="/dodaj" element={<AddStatementPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <footer className="container site-footer muted small">
        Dane w wersji demonstracyjnej są fikcyjne.
      </footer>
    </>
  );
}
