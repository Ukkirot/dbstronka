/** Hooki danych – cienka warstwa nad klientem API. */
import { getMeta, getPolitician, listPoliticians, listPredictions } from "../api/client";
import { serializeFilters, toApiQuery, type PredictionFilters } from "../lib/query";
import { useAsync } from "./useAsync";

export function usePredictions(filters: PredictionFilters) {
  // klucz zależności: serializowane filtry + polityk (nie jest w URL-u)
  const key = `${serializeFilters(filters).toString()}|${filters.politicianId ?? ""}`;
  return useAsync((signal) => listPredictions(toApiQuery(filters), signal), [key]);
}

export function useMeta() {
  return useAsync((signal) => getMeta(signal), []);
}

export function usePolitician(slug: string) {
  return useAsync((signal) => getPolitician(slug, signal), [slug]);
}

export function usePoliticians(q: string) {
  return useAsync((signal) => listPoliticians({ q: q.trim() || undefined }, signal), [q.trim()]);
}
