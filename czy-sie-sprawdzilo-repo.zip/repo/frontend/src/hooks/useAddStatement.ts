import { useCallback, useRef, useState } from "react";
import { createPolitician, createStatement } from "../api/client";
import type { StatementOut } from "../api/types";
import {
  emptyDraft,
  emptyPrediction,
  toPoliticianCreate,
  toStatementCreate,
  validateDraft,
  type DraftErrors,
  type PredictionDraft,
  type StatementDraft,
} from "../lib/validation";

/** Cała logika formularza dodawania wypowiedzi; widok tylko renderuje. */
export function useAddStatement(onPoliticianCreated?: () => void) {
  const counter = useRef(0);
  const nextKey = () => `p${counter.current++}`;

  const [draft, setDraft] = useState<StatementDraft>(() => emptyDraft(nextKey()));
  const [errors, setErrors] = useState<DraftErrors>({});
  const [serverError, setServerError] = useState<string>();
  const [submitting, setSubmitting] = useState(false);
  const [created, setCreated] = useState<StatementOut>();

  const setField = useCallback(<K extends keyof StatementDraft>(field: K, value: StatementDraft[K]) => {
    setDraft((d) => ({ ...d, [field]: value }));
    setErrors((e) => {
      if (!(field in e)) return e;
      const { [field as string]: _removed, ...rest } = e;
      return rest;
    });
  }, []);

  const addPrediction = useCallback(() => {
    setDraft((d) =>
      d.predictions.length >= 20 ? d : { ...d, predictions: [...d.predictions, emptyPrediction(nextKey())] },
    );
  }, []);

  const removePrediction = useCallback((index: number) => {
    setDraft((d) => ({ ...d, predictions: d.predictions.filter((_, i) => i !== index) }));
    setErrors({});
  }, []);

  const updatePrediction = useCallback(<K extends keyof PredictionDraft>(index: number, field: K, value: PredictionDraft[K]) => {
    setDraft((d) => ({
      ...d,
      predictions: d.predictions.map((p, i) => (i === index ? { ...p, [field]: value } : p)),
    }));
    setErrors((e) => {
      const key = `predictions.${index}.${String(field)}`;
      if (!(key in e)) return e;
      const { [key]: _removed, ...rest } = e;
      return rest;
    });
  }, []);

  const submit = useCallback(async () => {
    setServerError(undefined);
    const found = validateDraft(draft);
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    setSubmitting(true);
    try {
      let politicianId: number;
      if (draft.politicianMode === "new") {
        const politician = await createPolitician(toPoliticianCreate(draft));
        politicianId = politician.id;
        // przy ewentualnym błędzie wypowiedzi nie twórz polityka drugi raz
        setDraft((d) => ({ ...d, politicianMode: "existing", politicianId: String(politician.id) }));
        onPoliticianCreated?.();
      } else {
        politicianId = Number(draft.politicianId);
      }
      setCreated(await createStatement(toStatementCreate(draft, politicianId)));
    } catch (e) {
      setServerError(e instanceof Error ? e.message : "Nie udało się zapisać.");
    } finally {
      setSubmitting(false);
    }
  }, [draft, onPoliticianCreated]);

  const reset = useCallback(() => {
    setDraft(emptyDraft(nextKey()));
    setErrors({});
    setServerError(undefined);
    setCreated(undefined);
  }, []);

  return { draft, errors, serverError, submitting, created, setField, addPrediction, removePrediction, updatePrediction, submit, reset };
}
