import { Link } from "react-router-dom";
import type { PredictionOut } from "../api/types";
import { formatDate, fullName, hostname } from "../lib/format";
import { KIND_LABELS, VERIFIED_BY_LABELS } from "../lib/labels";
import { StatusBadge } from "./StatusBadge";

export function PredictionCard({ prediction: p }: { prediction: PredictionOut }) {
  const v = p.verification;
  return (
    <article className="card" aria-labelledby={`claim-${p.id}`}>
      <header className="card-head">
        <StatusBadge status={p.status} />
        <span className="chip">{KIND_LABELS[p.kind]}</span>
        {p.topic && <span className="chip">{p.topic}</span>}
      </header>

      <blockquote className="quote" cite={p.statement.source_url}>
        <p>{p.statement.text}</p>
      </blockquote>
      <p className="byline">
        —{" "}
        <Link to={`/politycy/${p.politician.slug}`}>{fullName(p.politician)}</Link>
        {p.politician.party && <span className="muted"> ({p.politician.party})</span>},{" "}
        <time dateTime={p.statement.statement_date}>{formatDate(p.statement.statement_date)}</time>
      </p>

      <dl className="facts">
        <dt>Sprawdzamy</dt>
        <dd id={`claim-${p.id}`}>{p.claim}</dd>
        {p.condition && (
          <>
            <dt>Warunek</dt>
            <dd>{p.condition}</dd>
          </>
        )}
        <dt>Termin</dt>
        <dd>{p.deadline ? <time dateTime={p.deadline}>{formatDate(p.deadline)}</time> : "brak"}</dd>
        {v?.fulfilled_at && (
          <>
            <dt>Spełniono</dt>
            <dd>
              <time dateTime={v.fulfilled_at}>{formatDate(v.fulfilled_at)}</time>
            </dd>
          </>
        )}
      </dl>

      {v ? (
        <section className="verdict" aria-label="Uzasadnienie oceny">
          {v.note && <p>{v.note}</p>}
          <p className="muted small">
            Oceniono {formatDate(v.verified_at)} · {VERIFIED_BY_LABELS[v.verified_by]}
          </p>
          {v.sources.length > 0 && (
            <ul className="sources">
              {v.sources.map((url) => (
                <li key={url}>
                  <a href={url} target="_blank" rel="noopener noreferrer">
                    {hostname(url)}
                    <span className="sr-only"> (otwiera się w nowej karcie)</span>
                  </a>
                </li>
              ))}
            </ul>
          )}
        </section>
      ) : (
        <p className="muted small">Ta predykcja nie została jeszcze oceniona.</p>
      )}

      <footer className="card-foot">
        <a href={p.statement.source_url} target="_blank" rel="noopener noreferrer">
          Źródło wypowiedzi ({hostname(p.statement.source_url)})
          <span className="sr-only"> – otwiera się w nowej karcie</span>
        </a>
      </footer>
    </article>
  );
}
