import type { AsyncState } from "../hooks/useAsync";
import type { PredictionPage } from "../api/types";
import { pluralize } from "../lib/format";
import { pageCount } from "../lib/query";
import { PredictionCard } from "./PredictionCard";
import { Pagination } from "./Pagination";
import { EmptyState, ErrorState, LoadingState } from "./States";

/** Wynik zapytania o predykcje: ładowanie / błąd / brak wyników / lista + paginacja. */
export function PredictionList({
  result,
  page,
  onPageChange,
  emptyHint,
}: {
  result: AsyncState<PredictionPage>;
  page: number;
  onPageChange: (page: number) => void;
  emptyHint?: string;
}) {
  const { data, error, loading, reload } = result;

  if (error) return <ErrorState error={error} onRetry={reload} />;
  if (!data) return <LoadingState />;

  return (
    <section aria-busy={loading}>
      <p className="result-count" role="status" aria-live="polite">
        {loading
          ? "Ładowanie…"
          : `${data.total} ${pluralize(data.total, "predykcja", "predykcje", "predykcji")}`}
      </p>
      {data.items.length === 0 ? (
        <EmptyState>
          <p>Nie znaleziono żadnych predykcji.</p>
          {emptyHint && <p className="muted">{emptyHint}</p>}
        </EmptyState>
      ) : (
        <div className={`cards${loading ? " is-loading" : ""}`}>
          {data.items.map((p) => (
            <PredictionCard key={p.id} prediction={p} />
          ))}
        </div>
      )}
      <Pagination page={page} pages={pageCount(data.total)} onChange={onPageChange} />
    </section>
  );
}
