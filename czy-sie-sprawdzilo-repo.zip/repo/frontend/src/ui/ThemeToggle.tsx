import { useTheme, type ThemeChoice } from "./theme";

const OPTIONS: { value: ThemeChoice; label: string }[] = [
  { value: "system", label: "Motyw systemowy" },
  { value: "light", label: "Motyw jasny" },
  { value: "dark", label: "Motyw ciemny" },
];

export function ThemeToggle() {
  const { choice, select } = useTheme();
  return (
    <label className="theme-toggle">
      <span className="sr-only">Motyw kolorystyczny</span>
      <select value={choice} onChange={(e) => select(e.target.value as ThemeChoice)}>
        {OPTIONS.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}
