import type { ReactNode } from "react";
import type { MetaOut } from "../api/types";
import { KIND_LABELS, STATUS_LABELS } from "../lib/labels";
import { SORT_PRESETS, type PredictionFilters, type SortPreset } from "../lib/query";

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="field">
      <span>{label}</span>
      {children}
    </label>
  );
}

export function FilterBar({
  filters,
  meta,
  searchValue,
  onSearchChange,
  onChange,
  onReset,
  canReset,
}: {
  filters: PredictionFilters;
  meta: MetaOut | undefined;
  searchValue: string;
  onSearchChange: (value: string) => void;
  onChange: (patch: Partial<PredictionFilters>) => void;
  onReset: () => void;
  canReset: boolean;
}) {
  return (
    <form className="filters" role="search" aria-label="Wyszukiwanie i filtry" onSubmit={(e) => e.preventDefault()}>
      <Field label="Szukaj w cytacie lub nazwisku">
        <input
          type="search"
          value={searchValue}
          placeholder="np. inflacja, Kowalski"
          onChange={(e) => onSearchChange(e.target.value)}
        />
      </Field>

      <div className="filter-grid">
        <Field label="Status">
          <select value={filters.status} onChange={(e) => onChange({ status: e.target.value as PredictionFilters["status"] })}>
            <option value="">Wszystkie</option>
            {(meta?.statuses ?? []).map((s) => (
              <option key={s} value={s}>
                {STATUS_LABELS[s]}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Partia">
          <select value={filters.party} onChange={(e) => onChange({ party: e.target.value })}>
            <option value="">Wszystkie</option>
            {(meta?.parties ?? []).map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Temat">
          <select value={filters.topic} onChange={(e) => onChange({ topic: e.target.value })}>
            <option value="">Wszystkie</option>
            {(meta?.topics ?? []).map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Rodzaj">
          <select value={filters.kind} onChange={(e) => onChange({ kind: e.target.value as PredictionFilters["kind"] })}>
            <option value="">Wszystkie</option>
            {(meta?.kinds ?? []).map((k) => (
              <option key={k} value={k}>
                {KIND_LABELS[k]}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Wypowiedź od">
          <input type="date" value={filters.dateFrom} max={filters.dateTo || undefined} onChange={(e) => onChange({ dateFrom: e.target.value })} />
        </Field>
        <Field label="Wypowiedź do">
          <input type="date" value={filters.dateTo} min={filters.dateFrom || undefined} onChange={(e) => onChange({ dateTo: e.target.value })} />
        </Field>
        <Field label="Sortowanie">
          <select value={filters.sort} onChange={(e) => onChange({ sort: e.target.value as SortPreset })}>
            {(Object.keys(SORT_PRESETS) as SortPreset[]).map((key) => (
              <option key={key} value={key}>
                {SORT_PRESETS[key].label}
              </option>
            ))}
          </select>
        </Field>
      </div>

      {canReset && (
        <button type="button" className="btn btn-link" onClick={onReset}>
          Wyczyść filtry
        </button>
      )}
    </form>
  );
}
