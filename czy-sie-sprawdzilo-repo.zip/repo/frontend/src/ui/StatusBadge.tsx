import type { Status } from "../api/types";
import { STATUS_ICONS, STATUS_LABELS } from "../lib/labels";

export function StatusBadge({ status }: { status: Status }) {
  return (
    <span className={`badge badge-${status}`}>
      <span aria-hidden="true">{STATUS_ICONS[status]}</span> {STATUS_LABELS[status]}
    </span>
  );
}
