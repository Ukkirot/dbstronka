import type { PoliticianStats } from "../api/types";
import { STATUS_LABELS } from "../lib/labels";
import { statusShares } from "../lib/stats";

export function ProportionBar({ stats }: { stats: PoliticianStats }) {
  const shares = statusShares(stats);
  if (shares.length === 0) return <p className="muted">Brak predykcji.</p>;
  const summary = shares.map((s) => `${STATUS_LABELS[s.status]}: ${s.count}`).join(", ");
  return (
    <div>
      <div className="bar" role="img" aria-label={`Proporcje statusów. ${summary}`}>
        {shares.map((s) => (
          <span key={s.status} className={`bar-seg bar-${s.status}`} style={{ flexGrow: s.count }} />
        ))}
      </div>
      <ul className="legend">
        {shares.map((s) => (
          <li key={s.status}>
            <span className={`dot bar-${s.status}`} aria-hidden="true" /> {STATUS_LABELS[s.status]}: <strong>{s.count}</strong>
          </li>
        ))}
      </ul>
    </div>
  );
}
