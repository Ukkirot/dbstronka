/** Motyw jasny/ciemny/systemowy – część warstwy widoku (używa DOM i localStorage). */
import { useCallback, useState } from "react";

export type ThemeChoice = "system" | "light" | "dark";
const KEY = "theme";

function read(): ThemeChoice {
  try {
    const v = localStorage.getItem(KEY);
    return v === "light" || v === "dark" ? v : "system";
  } catch {
    return "system";
  }
}

function apply(choice: ThemeChoice): void {
  const root = document.documentElement;
  if (choice === "system") delete root.dataset.theme;
  else root.dataset.theme = choice;
  try {
    if (choice === "system") localStorage.removeItem(KEY);
    else localStorage.setItem(KEY, choice);
  } catch {
    /* tryb prywatny – pomijamy */
  }
}

export function useTheme() {
  const [choice, setChoice] = useState<ThemeChoice>(read);
  const select = useCallback((next: ThemeChoice) => {
    apply(next);
    setChoice(next);
  }, []);
  return { choice, select };
}
