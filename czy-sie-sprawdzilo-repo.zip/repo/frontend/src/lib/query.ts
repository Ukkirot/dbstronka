/** Stan filtrów listy <-> parametry URL i zapytanie do API. Czysta logika. */
import type { PredictionQuery, SortKey, SortOrder } from "../api/client";
import type { Kind, Status } from "../api/types";
import { KINDS, STATUSES } from "./labels";

export const PAGE_SIZE = 20;

export type SortPreset = "newest" | "oldest" | "deadline" | "verified";

export const SORT_PRESETS: Record<SortPreset, { label: string; sort: SortKey; order: SortOrder }> = {
  newest: { label: "Najnowsze wypowiedzi", sort: "statement_date", order: "desc" },
  oldest: { label: "Najstarsze wypowiedzi", sort: "statement_date", order: "asc" },
  deadline: { label: "Najbliższy termin", sort: "deadline", order: "asc" },
  verified: { label: "Ostatnio zweryfikowane", sort: "verified_at", order: "desc" },
};

export interface PredictionFilters {
  q: string;
  status: Status | "";
  party: string;
  topic: string;
  kind: Kind | "";
  dateFrom: string;
  dateTo: string;
  sort: SortPreset;
  page: number; // od 1
  politicianId?: number;
}

export const DEFAULT_FILTERS: PredictionFilters = {
  q: "",
  status: "",
  party: "",
  topic: "",
  kind: "",
  dateFrom: "",
  dateTo: "",
  sort: "newest",
  page: 1,
};

export function toApiQuery(f: PredictionFilters): PredictionQuery {
  const preset = SORT_PRESETS[f.sort];
  return {
    q: f.q.trim() || undefined,
    status: f.status || undefined,
    party: f.party || undefined,
    topic: f.topic || undefined,
    kind: f.kind || undefined,
    date_from: f.dateFrom || undefined,
    date_to: f.dateTo || undefined,
    politician_id: f.politicianId,
    sort: preset.sort,
    order: preset.order,
    limit: PAGE_SIZE,
    offset: (f.page - 1) * PAGE_SIZE,
  };
}

export function parseFilters(params: URLSearchParams): PredictionFilters {
  const status = params.get("status") ?? "";
  const kind = params.get("kind") ?? "";
  const sort = params.get("sort") ?? "newest";
  const page = Number.parseInt(params.get("page") ?? "1", 10);
  return {
    q: params.get("q") ?? "",
    status: (STATUSES as string[]).includes(status) ? (status as Status) : "",
    party: params.get("party") ?? "",
    topic: params.get("topic") ?? "",
    kind: (KINDS as string[]).includes(kind) ? (kind as Kind) : "",
    dateFrom: params.get("from") ?? "",
    dateTo: params.get("to") ?? "",
    sort: sort in SORT_PRESETS ? (sort as SortPreset) : "newest",
    page: Number.isFinite(page) && page > 0 ? page : 1,
  };
}

/** Zapisuje tylko wartości różne od domyślnych (krótkie, udostępnialne adresy). */
export function serializeFilters(f: PredictionFilters): URLSearchParams {
  const params = new URLSearchParams();
  const set = (key: string, value: string) => value && params.set(key, value);
  set("q", f.q);
  set("status", f.status);
  set("party", f.party);
  set("topic", f.topic);
  set("kind", f.kind);
  set("from", f.dateFrom);
  set("to", f.dateTo);
  if (f.sort !== "newest") params.set("sort", f.sort);
  if (f.page > 1) params.set("page", String(f.page));
  return params;
}

export function hasActiveFilters(f: PredictionFilters): boolean {
  return Boolean(f.q || f.status || f.party || f.topic || f.kind || f.dateFrom || f.dateTo);
}

export function pageCount(total: number): number {
  return Math.max(1, Math.ceil(total / PAGE_SIZE));
}
