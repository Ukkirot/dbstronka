/** Wersja robocza formularza wypowiedzi, walidacja i mapowanie na payload API. */
import type { Kind, PoliticianCreate, StatementCreate } from "../api/types";

export interface PredictionDraft {
  key: string;
  kind: Kind;
  claim: string;
  condition: string;
  topic: string;
  deadline: string;
}

export interface StatementDraft {
  politicianMode: "existing" | "new";
  politicianId: string;
  newFirstName: string;
  newLastName: string;
  newParty: string;
  text: string;
  sourceUrl: string;
  statementDate: string;
  predictions: PredictionDraft[];
}

/** Klucze błędów: "text", "predictions.0.claim" itd. */
export type DraftErrors = Record<string, string>;

export const emptyPrediction = (key: string): PredictionDraft => ({
  key,
  kind: "prediction",
  claim: "",
  condition: "",
  topic: "",
  deadline: "",
});

export const emptyDraft = (firstKey: string): StatementDraft => ({
  politicianMode: "existing",
  politicianId: "",
  newFirstName: "",
  newLastName: "",
  newParty: "",
  text: "",
  sourceUrl: "",
  statementDate: "",
  predictions: [emptyPrediction(firstKey)],
});

export const isValidHttpUrl = (value: string): boolean => /^https?:\/\/[^\s/]+\S*$/i.test(value.trim());

export function validateDraft(d: StatementDraft): DraftErrors {
  const errors: DraftErrors = {};
  if (d.politicianMode === "existing") {
    if (!d.politicianId) errors.politicianId = "Wybierz polityka.";
  } else {
    if (!d.newFirstName.trim()) errors.newFirstName = "Podaj imię.";
    if (!d.newLastName.trim()) errors.newLastName = "Podaj nazwisko.";
  }
  if (!d.text.trim()) errors.text = "Wpisz dosłowny cytat.";
  if (!d.sourceUrl.trim()) errors.sourceUrl = "Podaj link do źródła.";
  else if (!isValidHttpUrl(d.sourceUrl)) errors.sourceUrl = "Adres musi zaczynać się od http:// lub https://";
  if (!d.statementDate) errors.statementDate = "Podaj datę wypowiedzi.";

  d.predictions.forEach((p, i) => {
    if (!p.claim.trim()) errors[`predictions.${i}.claim`] = "Opisz, co zostało przewidziane lub obiecane.";
    if (p.deadline && d.statementDate && p.deadline < d.statementDate) {
      errors[`predictions.${i}.deadline`] = "Termin nie może być wcześniejszy niż data wypowiedzi.";
    }
  });
  return errors;
}

export const toPoliticianCreate = (d: StatementDraft): PoliticianCreate => ({
  first_name: d.newFirstName.trim(),
  last_name: d.newLastName.trim(),
  party: d.newParty.trim() || null,
});

export const toStatementCreate = (d: StatementDraft, politicianId: number): StatementCreate => ({
  politician_id: politicianId,
  text: d.text.trim(),
  source_url: d.sourceUrl.trim(),
  statement_date: d.statementDate,
  predictions: d.predictions.map((p) => ({
    kind: p.kind,
    claim: p.claim.trim(),
    condition: p.condition.trim() || null,
    topic: p.topic.trim() || null,
    deadline: p.deadline || null,
  })),
});
