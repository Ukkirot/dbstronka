import type { Kind, Status } from "../api/types";

export const STATUSES: Status[] = ["true", "false", "partial", "unverifiable", "pending"];
export const KINDS: Kind[] = ["prediction", "promise"];

export const STATUS_LABELS: Record<Status, string> = {
  true: "Sprawdziło się",
  false: "Nie sprawdziło się",
  partial: "Częściowo",
  unverifiable: "Nie do zweryfikowania",
  pending: "Czeka na weryfikację",
};

/** Symbol obok koloru – status nie jest przekazywany wyłącznie barwą. */
export const STATUS_ICONS: Record<Status, string> = {
  true: "✓",
  false: "✗",
  partial: "◐",
  unverifiable: "?",
  pending: "…",
};

export const KIND_LABELS: Record<Kind, string> = {
  prediction: "Prognoza",
  promise: "Obietnica",
};

export const VERIFIED_BY_LABELS = { ai: "AI", human: "człowiek" } as const;
