/** Logika statystyk trafności (odpowiednik backendowego app/accuracy.py). */
import type { PoliticianStats, Status } from "../api/types";
import { STATUSES } from "./labels";

type Counts = Partial<Record<Status, number>>;

/** (true + 0.5 * partial) / rozstrzygnięte; null, gdy nic nie rozstrzygnięto. */
export function computeAccuracy(counts: Counts): number | null {
  const t = counts.true ?? 0;
  const p = counts.partial ?? 0;
  const f = counts.false ?? 0;
  const resolved = t + p + f;
  return resolved === 0 ? null : (t + 0.5 * p) / resolved;
}

/** Źródłem prawdy jest backend; wyliczenie lokalne to zabezpieczenie. */
export function accuracyOf(stats: PoliticianStats): number | null {
  return stats.accuracy ?? computeAccuracy(stats);
}

export interface StatusShare {
  status: Status;
  count: number;
  /** udział 0–1 w całości predykcji (do paska proporcji) */
  share: number;
}

export function statusShares(stats: PoliticianStats): StatusShare[] {
  const total = stats.total;
  return STATUSES.map((status) => ({
    status,
    count: stats[status],
    share: total === 0 ? 0 : stats[status] / total,
  })).filter((s) => s.count > 0);
}
