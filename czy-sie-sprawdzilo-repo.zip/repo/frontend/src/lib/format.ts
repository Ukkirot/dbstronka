/** Formatowanie – czyste funkcje, bez DOM. */

/** "2025-02-20" -> Date w czasie lokalnym (bez przesunięć strefowych). */
export function parseIsoDate(iso: string): Date {
  const [y, m, d] = iso.slice(0, 10).split("-").map(Number);
  return new Date(y, m - 1, d);
}

export function formatDate(iso: string | null | undefined): string {
  if (!iso) return "—";
  return new Intl.DateTimeFormat("pl-PL", { day: "numeric", month: "long", year: "numeric" }).format(
    parseIsoDate(iso),
  );
}

export function formatPercent(value: number | null | undefined): string {
  if (value === null || value === undefined) return "—";
  const pct = Math.round(value * 1000) / 10;
  return `${pct.toLocaleString("pl-PL", { maximumFractionDigits: 1 })}%`;
}

export function fullName(p: { first_name: string; last_name: string }): string {
  return `${p.first_name} ${p.last_name}`;
}

/** Nazwa hosta z URL-a bez klasy URL (działa wszędzie). */
export function hostname(url: string): string {
  const match = /^https?:\/\/([^/?#]+)/i.exec(url);
  return match ? match[1].replace(/^www\./, "") : url;
}

export function pluralize(n: number, one: string, few: string, many: string): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (n === 1) return one;
  if (mod10 >= 2 && mod10 <= 4 && !(mod100 >= 12 && mod100 <= 14)) return few;
  return many;
}
