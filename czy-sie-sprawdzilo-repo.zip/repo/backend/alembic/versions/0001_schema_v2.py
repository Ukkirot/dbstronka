"""Schemat v2: wykonuje DDL z schema/schema_v2.sql (bez danych przykładowych).

Revision ID: 0001
Revises:
"""
from alembic import op

from app.schema_sql import load_schema_parts, run_statements

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    ddl, _sample = load_schema_parts()
    bind = op.get_bind()
    run_statements(bind, ddl, bind.dialect.name)


def downgrade() -> None:
    for view in ("prediction_status", "current_verifications"):
        op.execute(f"DROP VIEW IF EXISTS {view}")
    for table in ("verifications", "predictions", "statements", "politicians"):
        op.execute(f"DROP TABLE IF EXISTS {table}")
