-- Schemat v2 (SQLite). Dla Postgresa: INTEGER PRIMARY KEY AUTOINCREMENT ->
-- BIGINT GENERATED ALWAYS AS IDENTITY, TIMESTAMP -> TIMESTAMPTZ.
-- WAŻNE (SQLite): klucze obce działają dopiero po PRAGMA foreign_keys = ON;
-- trzeba to ustawiać przy KAŻDYM połączeniu z bazą.

PRAGMA foreign_keys = ON;

CREATE TABLE politicians (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  first_name TEXT NOT NULL,
  last_name  TEXT NOT NULL,
  party      TEXT,
  slug       TEXT NOT NULL UNIQUE,  -- np. 'jan-przykladowy'; chroni przed duplikatami
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE statements (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  politician_id  INTEGER NOT NULL
                 REFERENCES politicians(id) ON DELETE RESTRICT,  -- nie usuwaj polityka z wypowiedziami
  text           TEXT NOT NULL,       -- dosłowny cytat
  source_url     TEXT NOT NULL,
  statement_date DATE NOT NULL,
  created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE predictions (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  statement_id INTEGER NOT NULL
               REFERENCES statements(id) ON DELETE CASCADE,      -- predykcja należy do wypowiedzi
  kind         TEXT NOT NULL CHECK (kind IN ('prediction','promise')),
  claim        TEXT NOT NULL,         -- treść prognozy/obietnicy
  condition    TEXT,                  -- mierzalny warunek do sprawdzenia
  topic        TEXT,
  deadline     DATE,                  -- do kiedy ma się spełnić
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Relacja 1:N celowo: historia ocen (audyt). Brak rekordu = predykcja czeka.
CREATE TABLE verifications (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  prediction_id INTEGER NOT NULL
                REFERENCES predictions(id) ON DELETE CASCADE,
  outcome       TEXT NOT NULL CHECK (outcome IN ('true','false','partial','unverifiable')),
  fulfilled_at  DATE,                 -- faktyczna data spełnienia
  note          TEXT,
  sources       TEXT,                 -- linki (JSON)
  verified_by   TEXT NOT NULL DEFAULT 'human' CHECK (verified_by IN ('ai','human')),
  verified_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,    -- UTC
  CHECK (fulfilled_at IS NULL OR outcome IN ('true','partial'))
);

CREATE INDEX idx_statements_politician ON statements(politician_id);
CREATE INDEX idx_predictions_statement ON predictions(statement_id);
CREATE INDEX idx_predictions_topic     ON predictions(topic);
CREATE INDEX idx_predictions_deadline  ON predictions(deadline);
CREATE INDEX idx_verifications_pred    ON verifications(prediction_id);

-- Aktualna ocena = najnowszy rekord weryfikacji danej predykcji.
CREATE VIEW current_verifications AS
SELECT v.*
FROM verifications v
WHERE v.id = (SELECT MAX(id) FROM verifications WHERE prediction_id = v.prediction_id);

-- Status predykcji: 'pending', gdy nie ma jeszcze żadnej weryfikacji.
CREATE VIEW prediction_status AS
SELECT p.id AS prediction_id,
       COALESCE(cv.outcome, 'pending') AS status
FROM predictions p
LEFT JOIN current_verifications cv ON cv.prediction_id = p.id;

-- Dane przykładowe (fikcyjne)
INSERT INTO politicians (first_name, last_name, party, slug) VALUES
  ('Jan',  'Przykładowy', 'Partia A', 'jan-przykladowy'),
  ('Anna', 'Testowa',     'Partia B', 'anna-testowa');

INSERT INTO statements (politician_id, text, source_url, statement_date) VALUES
  (1, 'W przyszłym roku inflacja wzrośnie o 8%.', 'https://example.com/1', '2024-01-10'),
  (2, 'Złoty umocni się poniżej 4 zł za euro.',   'https://example.com/2', '2025-02-20');

INSERT INTO predictions (statement_id, kind, claim, condition, topic, deadline) VALUES
  (1, 'prediction', 'Inflacja wzrośnie o 8%', 'CPI r/r w grudniu 2024 >= 8%', 'gospodarka', '2025-01-01'),
  (2, 'prediction', 'EUR/PLN poniżej 4,00',   'EUR/PLN < 4,00 do końca 2026', 'gospodarka', '2026-12-31');

INSERT INTO verifications (prediction_id, outcome, note, verified_by) VALUES
  (1, 'false', 'Według GUS inflacja była znacznie niższa.', 'human');
