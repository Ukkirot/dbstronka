import pytest

from app.accuracy import build_stats, compute_accuracy


def test_no_resolved_gives_none():
    assert compute_accuracy({}) is None
    assert compute_accuracy({"pending": 5, "unverifiable": 2}) is None


def test_formula_true_plus_half_partial_over_resolved():
    # (2 + 0.5*1) / (2 + 1 + 1) = 0.625
    assert compute_accuracy({"true": 2, "partial": 1, "false": 1}) == pytest.approx(0.625)


def test_unverifiable_and_pending_excluded_from_denominator():
    assert compute_accuracy({"true": 1, "false": 1, "unverifiable": 10, "pending": 10}) == pytest.approx(0.5)


def test_all_true_and_all_false():
    assert compute_accuracy({"true": 3}) == 1.0
    assert compute_accuracy({"false": 3}) == 0.0


def test_build_stats_totals():
    s = build_stats({"true": 2, "partial": 1, "false": 1, "unverifiable": 1, "pending": 1})
    assert s["total"] == 6 and s["resolved"] == 4 and s["accuracy"] == 0.625
