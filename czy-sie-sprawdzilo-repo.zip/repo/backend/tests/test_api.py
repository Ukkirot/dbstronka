import pytest

from tests.conftest import API, make_politician, make_statement, verify


# --- politycy ------------------------------------------------------------------
def test_create_politician_generates_slug_with_polish_letters(client):
    pol = make_politician(client, "Łukasz", "Żółć-Ąć", "Partia B")
    assert pol["slug"] == "lukasz-zolc-ac"
    assert pol["stats"]["accuracy"] is None


def test_duplicate_slug_returns_409(client):
    make_politician(client)
    r = client.post(f"{API}/politicians", json={"first_name": "Jan", "last_name": "Przykładowy"})
    assert r.status_code == 409


def test_validation_rejects_blank_name_and_bad_slug(client):
    assert client.post(f"{API}/politicians", json={"first_name": "  ", "last_name": "X"}).status_code == 422
    r = client.post(f"{API}/politicians", json={"first_name": "A", "last_name": "B", "slug": "Zły Slug"})
    assert r.status_code == 422


def test_patch_politician(client):
    pol = make_politician(client)
    r = client.patch(f"{API}/politicians/{pol['id']}", json={"party": "Partia Z"})
    assert r.status_code == 200 and r.json()["party"] == "Partia Z"
    r = client.patch(f"{API}/politicians/{pol['id']}", json={"party": None})
    assert r.json()["party"] is None
    assert client.patch(f"{API}/politicians/{pol['id']}", json={"first_name": None}).status_code == 422


def test_unknown_politician_slug_is_404(client):
    assert client.get(f"{API}/politicians/nie-ma").status_code == 404


def test_politicians_search_is_case_insensitive_for_polish_letters(client):
    make_politician(client, "Łukasz", "Zmyślony")
    make_politician(client, "Anna", "Testowa", "Partia B")
    found = client.get(f"{API}/politicians", params={"q": "ŁUK"}).json()
    assert [p["last_name"] for p in found] == ["Zmyślony"]
    assert len(client.get(f"{API}/politicians").json()) == 2


# --- wypowiedzi i predykcje -------------------------------------------------------
def test_statement_with_nested_predictions_starts_pending(client):
    pol = make_politician(client)
    st = make_statement(client, pol["id"], predictions=[
        {"claim": "A", "topic": "gospodarka"}, {"claim": "B", "kind": "promise"},
    ])
    assert len(st["predictions"]) == 2
    items = client.get(f"{API}/predictions").json()["items"]
    assert {i["status"] for i in items} == {"pending"}
    assert items[0]["verification"] is None


def test_statement_for_unknown_politician_is_404(client):
    r = client.post(f"{API}/statements", json={
        "politician_id": 999, "text": "x", "source_url": "https://a.b", "statement_date": "2024-01-01",
    })
    assert r.status_code == 404


def test_source_url_must_be_http(client):
    pol = make_politician(client)
    r = client.post(f"{API}/statements", json={
        "politician_id": pol["id"], "text": "x", "source_url": "ftp://a.b", "statement_date": "2024-01-01",
    })
    assert r.status_code == 422


def test_deadline_before_statement_date_is_rejected(client):
    pol = make_politician(client)
    r = client.post(f"{API}/statements", json={
        "politician_id": pol["id"], "text": "x", "source_url": "https://a.b", "statement_date": "2024-06-01",
        "predictions": [{"claim": "c", "deadline": "2024-01-01"}],
    })
    assert r.status_code == 422


def test_create_and_patch_prediction(client):
    pol = make_politician(client)
    st = make_statement(client, pol["id"], predictions=[])
    r = client.post(f"{API}/predictions", json={"statement_id": st["id"], "claim": "Nowa", "kind": "promise"})
    assert r.status_code == 201 and r.json()["status"] == "pending"
    pid = r.json()["id"]
    r = client.patch(f"{API}/predictions/{pid}", json={"topic": "zdrowie", "claim": "Zmieniona"})
    assert r.json()["topic"] == "zdrowie" and r.json()["claim"] == "Zmieniona"
    assert client.patch(f"{API}/predictions/{pid}", json={"claim": ""}).status_code == 422


# --- weryfikacje -----------------------------------------------------------------
def test_new_verification_appends_history_and_latest_wins(client):
    pol = make_politician(client)
    pid = make_statement(client, pol["id"])["predictions"][0]["id"]

    verify(client, pid, "false", note="Pierwsza ocena", verified_by="ai")
    assert client.get(f"{API}/predictions/{pid}").json()["status"] == "false"

    verify(client, pid, "true", fulfilled_at="2025-01-01", note="Korekta",
           sources=["https://example.com/a"])
    current = client.get(f"{API}/predictions/{pid}").json()
    assert current["status"] == "true"
    assert current["verification"]["note"] == "Korekta"
    assert current["verification"]["sources"] == ["https://example.com/a"]

    history = client.get(f"{API}/predictions/{pid}/verifications").json()
    assert [h["outcome"] for h in history] == ["true", "false"]  # nic nie nadpisano


def test_fulfilled_at_rejected_for_false_outcome(client):
    pol = make_politician(client)
    pid = make_statement(client, pol["id"])["predictions"][0]["id"]
    r = client.post(f"{API}/verifications", json={"prediction_id": pid, "outcome": "false", "fulfilled_at": "2025-01-01"})
    assert r.status_code == 422


def test_invalid_outcome_and_unknown_prediction(client):
    pol = make_politician(client)
    pid = make_statement(client, pol["id"])["predictions"][0]["id"]
    assert client.post(f"{API}/verifications", json={"prediction_id": pid, "outcome": "maybe"}).status_code == 422
    assert client.post(f"{API}/verifications", json={"prediction_id": 999, "outcome": "true"}).status_code == 404


def test_patch_verification_corrects_note_only(client):
    pol = make_politician(client)
    pid = make_statement(client, pol["id"])["predictions"][0]["id"]
    v = verify(client, pid, "partial", note="liturówka")
    r = client.patch(f"{API}/verifications/{v['id']}", json={"note": "literówka"})
    assert r.status_code == 200 and r.json()["note"] == "literówka" and r.json()["outcome"] == "partial"


# --- filtry, wyszukiwanie, sortowanie, paginacja -----------------------------------
@pytest.fixture
def populated(client):
    jan = make_politician(client, "Jan", "Przykładowy", "Partia A")
    anna = make_politician(client, "Anna", "Testowa", "Partia B")
    luk = make_politician(client, "Łukasz", "Zmyślony", "Partia A")
    s1 = make_statement(client, jan["id"], "Inflacja wzrośnie o 8%.", "2024-01-10",
                        [{"claim": "Inflacja 8%", "topic": "gospodarka", "deadline": "2025-01-01"}])
    s2 = make_statement(client, anna["id"], "Zbudujemy 100 tys. mieszkań.", "2025-02-20",
                        [{"claim": "100 tys. mieszkań", "kind": "promise", "topic": "mieszkalnictwo"}])
    s3 = make_statement(client, luk["id"], "Ceny prądu spadną.", "2025-08-01",
                        [{"claim": "Tańszy prąd", "topic": "energetyka", "deadline": "2026-01-01"}])
    verify(client, s1["predictions"][0]["id"], "false")
    verify(client, s3["predictions"][0]["id"], "true", fulfilled_at="2025-12-01")
    return {"jan": jan, "anna": anna, "luk": luk, "s1": s1, "s2": s2, "s3": s3}


def ids(client, **params):
    r = client.get(f"{API}/predictions", params=params)
    assert r.status_code == 200, r.text
    return [i["claim"] for i in r.json()["items"]], r.json()["total"]


def test_filter_by_status_including_pending(client, populated):
    assert ids(client, status="false")[0] == ["Inflacja 8%"]
    assert ids(client, status="true")[0] == ["Tańszy prąd"]
    assert ids(client, status="pending")[0] == ["100 tys. mieszkań"]


def test_filter_by_party_topic_kind_politician(client, populated):
    assert sorted(ids(client, party="Partia A")[0]) == ["Inflacja 8%", "Tańszy prąd"]
    assert ids(client, topic="energetyka")[0] == ["Tańszy prąd"]
    assert ids(client, kind="promise")[0] == ["100 tys. mieszkań"]
    assert ids(client, politician_id=populated["anna"]["id"])[0] == ["100 tys. mieszkań"]


def test_search_q_in_quote_and_name_case_insensitive(client, populated):
    assert ids(client, q="inflacja")[0] == ["Inflacja 8%"]       # w cytacie
    assert ids(client, q="ZMYŚLONY")[0] == ["Tańszy prąd"]        # w nazwisku
    assert ids(client, q="łukasz zmyślony")[0] == ["Tańszy prąd"]  # imię + nazwisko
    assert ids(client, q="%")[0] == ["Inflacja 8%"]  # % szukany dosłownie (cytat zawiera „8%”), nie jako wildcard
    assert ids(client, q="_")[1] == 0                # _ też nie jest wildcardem


def test_filter_by_statement_date_range(client, populated):
    assert ids(client, date_from="2025-01-01")[1] == 2
    assert ids(client, date_to="2024-12-31")[0] == ["Inflacja 8%"]
    assert ids(client, date_from="2025-02-20", date_to="2025-02-20")[0] == ["100 tys. mieszkań"]


def test_sorting_and_pagination(client, populated):
    newest, total = ids(client, sort="statement_date", order="desc")
    assert newest == ["Tańszy prąd", "100 tys. mieszkań", "Inflacja 8%"] and total == 3
    assert ids(client, sort="statement_date", order="asc")[0][0] == "Inflacja 8%"

    page, total = ids(client, limit=2, offset=0)
    assert len(page) == 2 and total == 3
    page2, _ = ids(client, limit=2, offset=2)
    assert page2 == ["Inflacja 8%"]


def test_sort_by_deadline_puts_nulls_last(client, populated):
    claims, _ = ids(client, sort="deadline", order="asc")
    assert claims[-1] == "100 tys. mieszkań"  # brak terminu


def test_invalid_params_return_422(client):
    assert client.get(f"{API}/predictions", params={"status": "nope"}).status_code == 422
    assert client.get(f"{API}/predictions", params={"limit": 1000}).status_code == 422
    assert client.get(f"{API}/predictions", params={"sort": "id; DROP TABLE x"}).status_code == 422


# --- statystyka trafności ---------------------------------------------------------
def test_politician_accuracy_stats(client):
    pol = make_politician(client)
    preds = [{"claim": f"p{i}"} for i in range(6)]
    st = make_statement(client, pol["id"], predictions=preds)
    pids = [p["id"] for p in st["predictions"]]
    for pid, outcome in zip(pids[:5], ["true", "true", "partial", "false", "unverifiable"]):
        verify(client, pid, outcome)
    # pids[5] zostaje 'pending'

    stats = client.get(f"{API}/politicians/{pol['slug']}").json()["stats"]
    assert stats == {"true": 2, "false": 1, "partial": 1, "unverifiable": 1, "pending": 1,
                     "total": 6, "resolved": 4, "accuracy": 0.625}

    listed = client.get(f"{API}/politicians").json()[0]["stats"]
    assert listed["accuracy"] == 0.625


def test_accuracy_uses_latest_verification_only(client):
    pol = make_politician(client)
    pid = make_statement(client, pol["id"])["predictions"][0]["id"]
    verify(client, pid, "false")
    verify(client, pid, "true")
    stats = client.get(f"{API}/politicians/{pol['slug']}").json()["stats"]
    assert stats["true"] == 1 and stats["false"] == 0 and stats["accuracy"] == 1.0


# --- meta / dokumentacja -------------------------------------------------------------
def test_meta_lists(client, populated):
    meta = client.get(f"{API}/meta").json()
    assert meta["parties"] == ["Partia A", "Partia B"]
    assert meta["topics"] == ["energetyka", "gospodarka", "mieszkalnictwo"]
    assert meta["statuses"] == ["true", "false", "partial", "unverifiable", "pending"]


def test_openapi_and_authorization_header_accepted(client):
    assert client.get(f"{API}/openapi.json").status_code == 200
    r = client.post(f"{API}/politicians", json={"first_name": "A", "last_name": "B"},
                    headers={"Authorization": "Bearer cokolwiek"})
    assert r.status_code == 201  # MVP: nagłówek akceptowany, ale jeszcze nie weryfikowany
