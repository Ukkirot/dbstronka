import pytest
from fastapi.testclient import TestClient

from app.db import make_engine
from app.main import create_app
from app.schema_sql import load_schema_parts, run_statements

API = "/api/v1"


@pytest.fixture
def client(tmp_path):
    """Czysta baza zbudowana z DDL ze schema_v2.sql (bez danych przykładowych)."""
    url = f"sqlite:///{tmp_path / 'test.db'}"
    engine = make_engine(url)
    ddl, _sample = load_schema_parts()
    with engine.begin() as conn:
        run_statements(conn, ddl, "sqlite")
    engine.dispose()

    app = create_app(url)
    with TestClient(app) as test_client:
        yield test_client
    app.state.engine.dispose()


def make_politician(client, first="Jan", last="Przykładowy", party="Partia A", **extra):
    r = client.post(f"{API}/politicians", json={"first_name": first, "last_name": last, "party": party, **extra})
    assert r.status_code == 201, r.text
    return r.json()


def make_statement(client, politician_id, text="Inflacja wzrośnie o 8%.", date="2024-01-10", predictions=None):
    if predictions is None:
        predictions = [{"claim": "Inflacja 8%", "topic": "gospodarka", "deadline": "2025-01-01"}]
    r = client.post(
        f"{API}/statements",
        json={
            "politician_id": politician_id,
            "text": text,
            "source_url": "https://example.com/x",
            "statement_date": date,
            "predictions": predictions,
        },
    )
    assert r.status_code == 201, r.text
    return r.json()


def verify(client, prediction_id, outcome, **extra):
    r = client.post(f"{API}/verifications", json={"prediction_id": prediction_id, "outcome": outcome, **extra})
    assert r.status_code == 201, r.text
    return r.json()
