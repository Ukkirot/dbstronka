import pytest
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError


def test_foreign_keys_pragma_is_on_for_every_connection(client):
    for _ in range(2):  # kolejne sesje = kolejne (lub ponownie użyte) połączenia
        with client.app.state.session_factory() as s:
            assert s.execute(text("PRAGMA foreign_keys")).scalar() == 1


def test_fk_violation_is_rejected(client):
    with client.app.state.session_factory() as s:
        with pytest.raises(IntegrityError):
            s.execute(
                text(
                    "INSERT INTO statements (politician_id, text, source_url, statement_date) "
                    "VALUES (999, 'x', 'https://a.b', '2024-01-01')"
                )
            )


def test_on_delete_restrict_blocks_deleting_politician_with_statements(client):
    from tests.conftest import make_politician, make_statement

    pol = make_politician(client)
    make_statement(client, pol["id"])
    with client.app.state.session_factory() as s:
        with pytest.raises(IntegrityError):
            s.execute(text("DELETE FROM politicians WHERE id = :id"), {"id": pol["id"]})
