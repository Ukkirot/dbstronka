"""Zapytania listujące: filtry, wyszukiwanie, sortowanie, statystyki."""
from dataclasses import dataclass
from datetime import date

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, contains_eager

from app.accuracy import STATUSES, build_stats
from app.models import CurrentVerification, Politician, Prediction, PredictionStatus, Statement
from app.schemas import (
    PoliticianBrief,
    PoliticianOut,
    PoliticianStats,
    PredictionOut,
    StatementBrief,
    VerificationOut,
)


def contains_ci(column, term: str, dialect: str):
    """LIKE '%term%' bez rozróżniania wielkości liter (także dla polskich znaków)."""
    escaped = term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    if dialect == "sqlite":
        return func.py_lower(column).like(f"%{escaped.lower()}%", escape="\\")
    return column.ilike(f"%{escaped}%", escape="\\")


@dataclass
class PredictionFilters:
    prediction_id: int | None = None
    status: str | None = None
    party: str | None = None
    topic: str | None = None
    politician_id: int | None = None
    kind: str | None = None
    q: str | None = None
    date_from: date | None = None
    date_to: date | None = None


SORT_COLUMNS = {
    "statement_date": Statement.statement_date,
    "deadline": Prediction.deadline,
    "verified_at": CurrentVerification.verified_at,
    "created_at": Prediction.created_at,
}


def _joined(*entities):
    return (
        select(*entities)
        .select_from(Prediction)
        .join(Statement, Statement.id == Prediction.statement_id)
        .join(Politician, Politician.id == Statement.politician_id)
        .join(PredictionStatus, PredictionStatus.prediction_id == Prediction.id)
        .outerjoin(CurrentVerification, CurrentVerification.prediction_id == Prediction.id)
    )


def _apply(query, f: PredictionFilters, dialect: str):
    if f.prediction_id is not None:
        query = query.where(Prediction.id == f.prediction_id)
    if f.status:
        query = query.where(PredictionStatus.status == f.status)
    if f.party:
        query = query.where(Politician.party == f.party)
    if f.topic:
        query = query.where(Prediction.topic == f.topic)
    if f.politician_id is not None:
        query = query.where(Politician.id == f.politician_id)
    if f.kind:
        query = query.where(Prediction.kind == f.kind)
    if f.date_from:
        query = query.where(Statement.statement_date >= f.date_from)
    if f.date_to:
        query = query.where(Statement.statement_date <= f.date_to)
    if f.q and f.q.strip():
        term = f.q.strip()
        query = query.where(
            or_(
                contains_ci(Statement.text, term, dialect),
                contains_ci(Politician.last_name, term, dialect),
                contains_ci(Politician.first_name, term, dialect),
                contains_ci(Politician.first_name + " " + Politician.last_name, term, dialect),
            )
        )
    return query


def to_prediction_out(pred: Prediction, status: str, cv: CurrentVerification | None) -> PredictionOut:
    return PredictionOut(
        id=pred.id,
        statement_id=pred.statement_id,
        kind=pred.kind,
        claim=pred.claim,
        condition=pred.condition,
        topic=pred.topic,
        deadline=pred.deadline,
        created_at=pred.created_at,
        status=status,
        statement=StatementBrief.model_validate(pred.statement),
        politician=PoliticianBrief.model_validate(pred.statement.politician),
        verification=VerificationOut.model_validate(cv) if cv is not None else None,
    )


def list_predictions(
    db: Session,
    f: PredictionFilters,
    sort: str = "statement_date",
    order: str = "desc",
    limit: int = 20,
    offset: int = 0,
) -> tuple[list[PredictionOut], int]:
    dialect = db.get_bind().dialect.name
    total = db.scalar(_apply(_joined(func.count(Prediction.id)), f, dialect)) or 0

    column = SORT_COLUMNS[sort]
    descending = order == "desc"
    primary = (column.desc() if descending else column.asc()).nulls_last()
    tiebreak = Prediction.id.desc() if descending else Prediction.id.asc()

    query = (
        _apply(_joined(Prediction, PredictionStatus.status, CurrentVerification), f, dialect)
        .options(contains_eager(Prediction.statement).contains_eager(Statement.politician))
        .order_by(primary, tiebreak)
        .limit(limit)
        .offset(offset)
    )
    rows = db.execute(query).all()
    return [to_prediction_out(p, s, cv) for p, s, cv in rows], total


def get_prediction_out(db: Session, prediction_id: int) -> PredictionOut | None:
    items, _ = list_predictions(db, PredictionFilters(prediction_id=prediction_id), limit=1)
    return items[0] if items else None


def stats_for(db: Session, politician_ids: list[int]) -> dict[int, PoliticianStats]:
    counts: dict[int, dict[str, int]] = {pid: {} for pid in politician_ids}
    if politician_ids:
        rows = db.execute(
            select(Statement.politician_id, PredictionStatus.status, func.count())
            .select_from(Prediction)
            .join(Statement, Statement.id == Prediction.statement_id)
            .join(PredictionStatus, PredictionStatus.prediction_id == Prediction.id)
            .where(Statement.politician_id.in_(politician_ids))
            .group_by(Statement.politician_id, PredictionStatus.status)
        ).all()
        for pid, status, n in rows:
            if status in STATUSES:
                counts[pid][status] = n
    return {pid: PoliticianStats(**build_stats(c)) for pid, c in counts.items()}


def to_politician_out(politician: Politician, stats: PoliticianStats) -> PoliticianOut:
    return PoliticianOut(
        id=politician.id,
        first_name=politician.first_name,
        last_name=politician.last_name,
        party=politician.party,
        slug=politician.slug,
        created_at=politician.created_at,
        stats=stats,
    )
