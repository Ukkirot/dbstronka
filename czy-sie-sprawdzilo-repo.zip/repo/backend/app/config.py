"""Konfiguracja z zmiennych środowiskowych."""
import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    # SQLite (domyślnie, ścieżka względem katalogu, z którego uruchamiasz backend):
    #   sqlite:///./czy_sie_sprawdzilo.db
    # Postgres:
    #   postgresql+psycopg://user:haslo@localhost:5432/czy_sie_sprawdzilo
    database_url: str = "sqlite:///./czy_sie_sprawdzilo.db"
    cors_origins: tuple[str, ...] = ("http://localhost:5173", "http://127.0.0.1:5173")


def get_settings() -> Settings:
    origins = os.getenv("CORS_ORIGINS")
    return Settings(
        database_url=os.getenv("DATABASE_URL", Settings.database_url),
        cors_origins=tuple(o.strip() for o in origins.split(",") if o.strip())
        if origins
        else Settings.cors_origins,
    )
