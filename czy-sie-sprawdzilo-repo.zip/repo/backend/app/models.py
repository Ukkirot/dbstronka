"""Mapowanie ORM na schema_v2.sql. Schemat tworzy migracja/DDL – NIE Base.metadata.create_all()."""
from datetime import date, datetime

from sqlalchemy import Date, DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class Politician(Base):
    __tablename__ = "politicians"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    first_name: Mapped[str] = mapped_column(Text)
    last_name: Mapped[str] = mapped_column(Text)
    party: Mapped[str | None] = mapped_column(Text, nullable=True)
    slug: Mapped[str] = mapped_column(Text, unique=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.current_timestamp())

    statements: Mapped[list["Statement"]] = relationship(back_populates="politician", passive_deletes=True)


class Statement(Base):
    __tablename__ = "statements"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    politician_id: Mapped[int] = mapped_column(ForeignKey("politicians.id", ondelete="RESTRICT"))
    text: Mapped[str] = mapped_column(Text)
    source_url: Mapped[str] = mapped_column(Text)
    statement_date: Mapped[date] = mapped_column(Date)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.current_timestamp())

    politician: Mapped[Politician] = relationship(back_populates="statements")
    predictions: Mapped[list["Prediction"]] = relationship(
        back_populates="statement", passive_deletes=True, order_by="Prediction.id"
    )


class Prediction(Base):
    __tablename__ = "predictions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    statement_id: Mapped[int] = mapped_column(ForeignKey("statements.id", ondelete="CASCADE"))
    kind: Mapped[str] = mapped_column(Text)
    claim: Mapped[str] = mapped_column(Text)
    condition: Mapped[str | None] = mapped_column(Text, nullable=True)
    topic: Mapped[str | None] = mapped_column(Text, nullable=True)
    deadline: Mapped[date | None] = mapped_column(Date, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.current_timestamp())

    statement: Mapped[Statement] = relationship(back_populates="predictions")
    verifications: Mapped[list["Verification"]] = relationship(
        back_populates="prediction", passive_deletes=True, order_by="Verification.id"
    )


class Verification(Base):
    __tablename__ = "verifications"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    prediction_id: Mapped[int] = mapped_column(ForeignKey("predictions.id", ondelete="CASCADE"))
    outcome: Mapped[str] = mapped_column(Text)
    fulfilled_at: Mapped[date | None] = mapped_column(Date, nullable=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    sources: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON (lista linków)
    verified_by: Mapped[str] = mapped_column(Text, server_default="human")
    verified_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.current_timestamp())

    prediction: Mapped[Prediction] = relationship(back_populates="verifications")


# --- Widoki (tylko do odczytu) ------------------------------------------------
class CurrentVerification(Base):
    """Widok current_verifications: najnowsza weryfikacja każdej predykcji."""

    __tablename__ = "current_verifications"
    __table_args__ = {"info": {"is_view": True}}
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    prediction_id: Mapped[int] = mapped_column(Integer)
    outcome: Mapped[str] = mapped_column(Text)
    fulfilled_at: Mapped[date | None] = mapped_column(Date, nullable=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    sources: Mapped[str | None] = mapped_column(Text, nullable=True)
    verified_by: Mapped[str] = mapped_column(Text)
    verified_at: Mapped[datetime] = mapped_column(DateTime)


class PredictionStatus(Base):
    """Widok prediction_status: 'pending' albo wynik ostatniej weryfikacji."""

    __tablename__ = "prediction_status"
    __table_args__ = {"info": {"is_view": True}}
    prediction_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    status: Mapped[str] = mapped_column(String)
