"""Wczytywanie schema_v2.sql (źródło prawdy) i wykonywanie go przez SQLAlchemy.

Plik schema_v2.sql nie jest modyfikowany. Dzielimy go tylko w pamięci na:
  * DDL (tabele, indeksy, widoki) – używany przez migrację Alembic i testy,
  * dane przykładowe (po znaczniku SAMPLE_MARKER) – używane przez seed.
"""
import re
from pathlib import Path

SCHEMA_PATH = Path(__file__).resolve().parents[1] / "schema" / "schema_v2.sql"
SAMPLE_MARKER = "-- Dane przykładowe (fikcyjne)"


def load_schema_parts() -> tuple[str, str]:
    sql = SCHEMA_PATH.read_text(encoding="utf-8")
    ddl, _, sample = sql.partition(SAMPLE_MARKER)
    return ddl, sample


def split_statements(sql: str) -> list[str]:
    """Dzieli SQL po ';' z pominięciem komentarzy `--` i średników w literałach '...'."""
    statements: list[str] = []
    buf: list[str] = []
    in_str = False
    i, n = 0, len(sql)
    while i < n:
        ch = sql[i]
        if in_str:
            buf.append(ch)
            if ch == "'":
                if i + 1 < n and sql[i + 1] == "'":
                    buf.append("'")
                    i += 1
                else:
                    in_str = False
        elif ch == "'":
            in_str = True
            buf.append(ch)
        elif ch == "-" and sql.startswith("--", i):
            j = sql.find("\n", i)
            i = n if j == -1 else j
            continue
        elif ch == ";":
            stmt = "".join(buf).strip()
            if stmt:
                statements.append(stmt)
            buf = []
        else:
            buf.append(ch)
        i += 1
    tail = "".join(buf).strip()
    if tail:
        statements.append(tail)
    return statements


def adapt(statement: str, dialect: str) -> str | None:
    """SQLite: bez zmian. Postgres: tłumaczenie wg uwag z nagłówka schema_v2.sql."""
    if dialect == "sqlite":
        return statement
    if statement.upper().startswith("PRAGMA"):
        return None
    statement = statement.replace(
        "INTEGER PRIMARY KEY AUTOINCREMENT",
        "BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY",
    )
    return re.sub(r"\bTIMESTAMP\b", "TIMESTAMPTZ", statement)


def run_statements(connection, sql: str, dialect: str) -> None:  # noqa: ANN001
    for statement in split_statements(sql):
        adapted = adapt(statement, dialect)
        if adapted:
            connection.exec_driver_sql(adapted)
