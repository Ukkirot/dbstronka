from typing import Annotated

from fastapi import Depends, Header, HTTPException
from sqlalchemy.orm import Session

from app.db import get_db

DbDep = Annotated[Session, Depends(get_db)]


def authorize(authorization: Annotated[str | None, Header()] = None) -> None:
    """MIEJSCE NA AUTORYZACJĘ. W MVP endpointy zapisu są otwarte.

    Docelowo: sprawdź `Authorization: Bearer <token>` i zwróć 401/403.
    Podpięte pod wszystkie POST/PATCH, więc zmiana jest w jednym miejscu.
    """
    return None


def get_or_404(db: Session, model, obj_id: int, label: str):
    obj = db.get(model, obj_id)
    if obj is None:
        raise HTTPException(status_code=404, detail=f"Nie znaleziono: {label} (id={obj_id}).")
    return obj


def apply_patch(obj, data: dict, nullable: set[str]) -> None:
    for key, value in data.items():
        if value is None and key not in nullable:
            raise HTTPException(status_code=422, detail=f"Pole „{key}” nie może być puste.")
        setattr(obj, key, value)


def check_deadline(statement_date, deadline) -> None:
    if deadline is not None and deadline < statement_date:
        raise HTTPException(
            status_code=422, detail="Termin (deadline) nie może być wcześniejszy niż data wypowiedzi."
        )
