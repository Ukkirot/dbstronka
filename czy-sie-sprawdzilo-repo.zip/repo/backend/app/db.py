"""Silnik SQLAlchemy. Dla SQLite KAŻDE nowe połączenie dostaje PRAGMA foreign_keys = ON."""
from collections.abc import Iterator

from fastapi import Request
from sqlalchemy import Engine, create_engine, event
from sqlalchemy.orm import Session, sessionmaker


def _py_lower(value):
    # Wbudowane lower() w SQLite zna tylko ASCII (Ł nie zmieni się w ł),
    # dlatego rejestrujemy własną funkcję, która obsługuje polskie znaki.
    return value.lower() if isinstance(value, str) else value


def make_engine(url: str) -> Engine:
    kwargs: dict = {}
    if url.startswith("sqlite"):
        kwargs["connect_args"] = {"check_same_thread": False}
    engine = create_engine(url, **kwargs)

    if engine.dialect.name == "sqlite":

        @event.listens_for(engine, "connect")
        def _on_connect(dbapi_connection, _record):  # noqa: ANN001
            cursor = dbapi_connection.cursor()
            cursor.execute("PRAGMA foreign_keys = ON")
            cursor.close()
            dbapi_connection.create_function("py_lower", 1, _py_lower, deterministic=True)

    return engine


def make_session_factory(engine: Engine) -> sessionmaker[Session]:
    return sessionmaker(bind=engine, expire_on_commit=False)


def get_db(request: Request) -> Iterator[Session]:
    with request.app.state.session_factory() as session:
        yield session
