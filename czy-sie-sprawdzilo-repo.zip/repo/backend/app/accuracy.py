"""Trafność predykcji: (true + 0.5 * partial) / rozstrzygnięte.

Rozstrzygnięte = true + partial + false. Statusy 'unverifiable' i 'pending'
nie wchodzą do mianownika. Brak rozstrzygniętych => None (a nie 0%).
"""
from collections.abc import Mapping

STATUSES = ("true", "false", "partial", "unverifiable", "pending")


def compute_accuracy(counts: Mapping[str, int]) -> float | None:
    true = counts.get("true", 0)
    partial = counts.get("partial", 0)
    false = counts.get("false", 0)
    resolved = true + partial + false
    if resolved == 0:
        return None
    return (true + 0.5 * partial) / resolved


def build_stats(counts: Mapping[str, int]) -> dict:
    full = {status: int(counts.get(status, 0)) for status in STATUSES}
    resolved = full["true"] + full["partial"] + full["false"]
    accuracy = compute_accuracy(full)
    return {
        **full,
        "total": sum(full.values()),
        "resolved": resolved,
        "accuracy": None if accuracy is None else round(accuracy, 4),
    }
