from fastapi import APIRouter
from sqlalchemy import select

from app.accuracy import STATUSES
from app.deps import DbDep
from app.models import Politician, Prediction
from app.schemas import MetaOut

router = APIRouter(prefix="/meta", tags=["meta"])


@router.get("", response_model=MetaOut, summary="Listy do filtrów: partie, tematy, statusy")
def get_meta(db: DbDep) -> MetaOut:
    parties = db.scalars(
        select(Politician.party).where(Politician.party.is_not(None)).distinct().order_by(Politician.party)
    ).all()
    topics = db.scalars(
        select(Prediction.topic).where(Prediction.topic.is_not(None)).distinct().order_by(Prediction.topic)
    ).all()
    return MetaOut(
        parties=list(parties),
        topics=list(topics),
        statuses=list(STATUSES),  # type: ignore[arg-type]
        kinds=["prediction", "promise"],
    )
