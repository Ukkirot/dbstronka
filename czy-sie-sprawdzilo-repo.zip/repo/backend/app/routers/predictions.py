from datetime import date
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException, Query

from app.deps import DbDep, apply_patch, authorize, check_deadline, get_or_404
from app.models import Prediction, Statement, Verification
from app.queries import PredictionFilters, get_prediction_out, list_predictions
from app.schemas import (
    Kind,
    PredictionCreate,
    PredictionOut,
    PredictionPage,
    PredictionUpdate,
    Status,
    VerificationOut,
)

router = APIRouter(prefix="/predictions", tags=["predictions"])

SortKey = Literal["statement_date", "deadline", "verified_at", "created_at"]
Order = Literal["asc", "desc"]


@router.get("", response_model=PredictionPage, summary="Lista predykcji z filtrami")
def list_(
    db: DbDep,
    status: Annotated[Status | None, Query(description="Aktualny status (z widoku prediction_status)")] = None,
    party: str | None = None,
    topic: str | None = None,
    politician_id: int | None = None,
    kind: Kind | None = None,
    q: Annotated[str | None, Query(max_length=200, description="Szukaj w cytacie i nazwisku")] = None,
    date_from: Annotated[date | None, Query(description="Data wypowiedzi od (włącznie)")] = None,
    date_to: Annotated[date | None, Query(description="Data wypowiedzi do (włącznie)")] = None,
    sort: SortKey = "statement_date",
    order: Order = "desc",
    limit: Annotated[int, Query(ge=1, le=100)] = 20,
    offset: Annotated[int, Query(ge=0)] = 0,
) -> PredictionPage:
    filters = PredictionFilters(
        status=status,
        party=party,
        topic=topic,
        politician_id=politician_id,
        kind=kind,
        q=q,
        date_from=date_from,
        date_to=date_to,
    )
    items, total = list_predictions(db, filters, sort, order, limit, offset)
    return PredictionPage(items=items, total=total, limit=limit, offset=offset)


@router.get("/{prediction_id}", response_model=PredictionOut)
def get_one(prediction_id: int, db: DbDep) -> PredictionOut:
    out = get_prediction_out(db, prediction_id)
    if out is None:
        raise HTTPException(404, f"Nie znaleziono: predykcji (id={prediction_id}).")
    return out


@router.get(
    "/{prediction_id}/verifications",
    response_model=list[VerificationOut],
    summary="Historia ocen predykcji (od najnowszej)",
)
def history(prediction_id: int, db: DbDep) -> list[Verification]:
    get_or_404(db, Prediction, prediction_id, "predykcji")
    return (
        db.query(Verification)
        .filter(Verification.prediction_id == prediction_id)
        .order_by(Verification.id.desc())
        .all()
    )


@router.post("", response_model=PredictionOut, status_code=201, dependencies=[Depends(authorize)])
def create(body: PredictionCreate, db: DbDep) -> PredictionOut:
    statement = get_or_404(db, Statement, body.statement_id, "wypowiedzi")
    check_deadline(statement.statement_date, body.deadline)
    pred = Prediction(**body.model_dump())
    db.add(pred)
    db.commit()
    return get_prediction_out(db, pred.id)  # type: ignore[return-value]


@router.patch("/{prediction_id}", response_model=PredictionOut, dependencies=[Depends(authorize)])
def update(prediction_id: int, body: PredictionUpdate, db: DbDep) -> PredictionOut:
    pred = get_or_404(db, Prediction, prediction_id, "predykcji")
    data = body.model_dump(exclude_unset=True)
    if data.get("deadline") is not None:
        check_deadline(pred.statement.statement_date, data["deadline"])
    apply_patch(pred, data, nullable={"condition", "topic", "deadline"})
    db.commit()
    return get_prediction_out(db, prediction_id)  # type: ignore[return-value]
