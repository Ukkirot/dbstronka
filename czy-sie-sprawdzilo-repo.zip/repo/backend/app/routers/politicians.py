import re
import unicodedata
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select

from app.deps import DbDep, apply_patch, authorize, get_or_404
from app.models import Politician
from app.queries import contains_ci, stats_for, to_politician_out
from app.schemas import PoliticianCreate, PoliticianOut, PoliticianUpdate

router = APIRouter(prefix="/politicians", tags=["politicians"])

_PL = str.maketrans({"ł": "l", "Ł": "L"})


def slugify(first_name: str, last_name: str) -> str:
    raw = f"{first_name} {last_name}".translate(_PL)
    ascii_text = unicodedata.normalize("NFKD", raw).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "-", ascii_text.lower()).strip("-")


def _ensure_slug_free(db, slug: str, exclude_id: int | None = None) -> None:
    existing = db.scalar(select(Politician.id).where(Politician.slug == slug))
    if existing is not None and existing != exclude_id:
        raise HTTPException(409, f"Slug „{slug}” jest już zajęty – podaj własny (pole slug).")


@router.get("", response_model=list[PoliticianOut], summary="Lista polityków (q = imię/nazwisko)")
def list_(
    db: DbDep,
    q: Annotated[str | None, Query(max_length=200)] = None,
    party: str | None = None,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    offset: Annotated[int, Query(ge=0)] = 0,
) -> list[PoliticianOut]:
    dialect = db.get_bind().dialect.name
    query = select(Politician)
    if q and q.strip():
        term = q.strip()
        query = query.where(
            contains_ci(Politician.first_name + " " + Politician.last_name, term, dialect)
        )
    if party:
        query = query.where(Politician.party == party)
    query = query.order_by(Politician.last_name, Politician.first_name, Politician.id)
    politicians = db.scalars(query.limit(limit).offset(offset)).all()
    stats = stats_for(db, [p.id for p in politicians])
    return [to_politician_out(p, stats[p.id]) for p in politicians]


@router.get("/{slug}", response_model=PoliticianOut, summary="Polityk + statystyka trafności")
def get_one(slug: str, db: DbDep) -> PoliticianOut:
    politician = db.scalar(select(Politician).where(Politician.slug == slug))
    if politician is None:
        raise HTTPException(404, f"Nie znaleziono polityka „{slug}”.")
    return to_politician_out(politician, stats_for(db, [politician.id])[politician.id])


@router.post("", response_model=PoliticianOut, status_code=201, dependencies=[Depends(authorize)])
def create(body: PoliticianCreate, db: DbDep) -> PoliticianOut:
    slug = body.slug or slugify(body.first_name, body.last_name)
    if not slug:
        raise HTTPException(422, "Nie można wygenerować sluga – podaj go ręcznie.")
    _ensure_slug_free(db, slug)
    politician = Politician(
        first_name=body.first_name, last_name=body.last_name, party=body.party, slug=slug
    )
    db.add(politician)
    db.commit()
    db.refresh(politician)
    return to_politician_out(politician, stats_for(db, [politician.id])[politician.id])


@router.patch("/{politician_id}", response_model=PoliticianOut, dependencies=[Depends(authorize)])
def update(politician_id: int, body: PoliticianUpdate, db: DbDep) -> PoliticianOut:
    politician = get_or_404(db, Politician, politician_id, "polityka")
    data = body.model_dump(exclude_unset=True)
    if data.get("slug"):
        _ensure_slug_free(db, data["slug"], exclude_id=politician_id)
    apply_patch(politician, data, nullable={"party"})
    db.commit()
    db.refresh(politician)
    return to_politician_out(politician, stats_for(db, [politician.id])[politician.id])
