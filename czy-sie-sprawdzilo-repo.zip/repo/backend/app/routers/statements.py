from fastapi import APIRouter, Depends

from app.deps import DbDep, apply_patch, authorize, check_deadline, get_or_404
from app.models import Politician, Prediction, Statement
from app.schemas import StatementCreate, StatementOut, StatementUpdate

router = APIRouter(prefix="/statements", tags=["statements"])


@router.get("/{statement_id}", response_model=StatementOut)
def get_one(statement_id: int, db: DbDep) -> Statement:
    return get_or_404(db, Statement, statement_id, "wypowiedzi")


@router.post("", response_model=StatementOut, status_code=201, dependencies=[Depends(authorize)])
def create(body: StatementCreate, db: DbDep) -> Statement:
    """Tworzy wypowiedź razem z predykcjami (jedna transakcja)."""
    get_or_404(db, Politician, body.politician_id, "polityka")
    statement = Statement(
        politician_id=body.politician_id,
        text=body.text,
        source_url=body.source_url,
        statement_date=body.statement_date,
    )
    for inline in body.predictions:
        check_deadline(body.statement_date, inline.deadline)
        statement.predictions.append(Prediction(**inline.model_dump()))
    db.add(statement)
    db.commit()
    db.refresh(statement)
    return statement


@router.patch("/{statement_id}", response_model=StatementOut, dependencies=[Depends(authorize)])
def update(statement_id: int, body: StatementUpdate, db: DbDep) -> Statement:
    statement = get_or_404(db, Statement, statement_id, "wypowiedzi")
    apply_patch(statement, body.model_dump(exclude_unset=True), nullable=set())
    db.commit()
    db.refresh(statement)
    return statement
