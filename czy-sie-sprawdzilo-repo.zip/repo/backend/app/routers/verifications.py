import json

from fastapi import APIRouter, Depends

from app.deps import DbDep, apply_patch, authorize, get_or_404
from app.models import Prediction, Verification
from app.schemas import VerificationCreate, VerificationOut, VerificationUpdate

router = APIRouter(prefix="/verifications", tags=["verifications"])


def _dump_sources(sources: list[str] | None) -> str | None:
    return json.dumps(sources, ensure_ascii=False) if sources else None


@router.post("", response_model=VerificationOut, status_code=201, dependencies=[Depends(authorize)])
def create(body: VerificationCreate, db: DbDep) -> Verification:
    """Zawsze DODAJE rekord (historia ocen). Aktualna ocena = najnowszy rekord."""
    get_or_404(db, Prediction, body.prediction_id, "predykcji")
    verification = Verification(
        prediction_id=body.prediction_id,
        outcome=body.outcome,
        fulfilled_at=body.fulfilled_at,
        note=body.note,
        sources=_dump_sources(body.sources),
        verified_by=body.verified_by,
    )
    db.add(verification)
    db.commit()
    db.refresh(verification)
    return verification


@router.patch(
    "/{verification_id}",
    response_model=VerificationOut,
    dependencies=[Depends(authorize)],
    summary="Korekta uzasadnienia/źródeł (nie zmienia wyniku)",
)
def update(verification_id: int, body: VerificationUpdate, db: DbDep) -> Verification:
    verification = get_or_404(db, Verification, verification_id, "weryfikacji")
    data = body.model_dump(exclude_unset=True)
    if "sources" in data:
        data["sources"] = _dump_sources(data["sources"])
    apply_patch(verification, data, nullable={"note", "sources"})
    db.commit()
    db.refresh(verification)
    return verification
