"""Modele Pydantic (żądania i odpowiedzi). Nazwy klas trafiają do OpenAPI i do typów TS."""
import json
from datetime import date, datetime, timezone
from typing import Annotated, Literal, Optional
from urllib.parse import urlparse

from pydantic import (
    AfterValidator,
    BaseModel,
    BeforeValidator,
    ConfigDict,
    Field,
    StringConstraints,
    field_validator,
    model_validator,
)

Outcome = Literal["true", "false", "partial", "unverifiable"]
Status = Literal["true", "false", "partial", "unverifiable", "pending"]
Kind = Literal["prediction", "promise"]
VerifiedBy = Literal["ai", "human"]


# --- Typy pomocnicze ----------------------------------------------------------
def _as_utc(value: datetime) -> datetime:
    # CURRENT_TIMESTAMP w bazie jest w UTC; dopisujemy strefę, by JSON miał "Z".
    return value if value.tzinfo else value.replace(tzinfo=timezone.utc)


UTCDateTime = Annotated[datetime, AfterValidator(_as_utc)]


def _blank_to_none(value):
    if isinstance(value, str):
        value = value.strip()
        return value or None
    return value


def req_str(max_length: int):
    return Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=max_length)]


def opt_str(max_length: int):
    return Annotated[
        Optional[Annotated[str, StringConstraints(max_length=max_length)]],
        BeforeValidator(_blank_to_none),
    ]


def _check_url(value: str) -> str:
    parsed = urlparse(value)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ValueError("Adres musi zaczynać się od http:// lub https://")
    return value


Url = Annotated[str, StringConstraints(strip_whitespace=True, max_length=2000), AfterValidator(_check_url)]
Slug = Annotated[str, StringConstraints(min_length=1, max_length=100, pattern=r"^[a-z0-9]+(-[a-z0-9]+)*$")]


class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# --- Statystyki ---------------------------------------------------------------
class PoliticianStats(BaseModel):
    true: int
    false: int
    partial: int
    unverifiable: int
    pending: int
    total: int
    resolved: int
    accuracy: Optional[float]  # (true + 0.5*partial) / resolved; null gdy resolved == 0


# --- Politycy -----------------------------------------------------------------
class PoliticianBrief(ORMModel):
    id: int
    first_name: str
    last_name: str
    party: Optional[str]
    slug: str


class PoliticianOut(PoliticianBrief):
    created_at: UTCDateTime
    stats: PoliticianStats


class PoliticianCreate(BaseModel):
    first_name: req_str(100)
    last_name: req_str(100)
    party: opt_str(100) = None
    slug: Optional[Slug] = None  # gdy brak – generowany z imienia i nazwiska


class PoliticianUpdate(BaseModel):
    first_name: Optional[req_str(100)] = None
    last_name: Optional[req_str(100)] = None
    party: opt_str(100) = None
    slug: Optional[Slug] = None


# --- Wypowiedzi ---------------------------------------------------------------
class StatementBrief(ORMModel):
    id: int
    text: str
    source_url: str
    statement_date: date


class PredictionInline(BaseModel):
    kind: Kind = "prediction"
    claim: req_str(1000)
    condition: opt_str(1000) = None
    topic: opt_str(100) = None
    deadline: Optional[date] = None


class PredictionBrief(ORMModel):
    id: int
    statement_id: int
    kind: Kind
    claim: str
    condition: Optional[str]
    topic: Optional[str]
    deadline: Optional[date]
    created_at: UTCDateTime


class StatementCreate(BaseModel):
    politician_id: int
    text: req_str(5000)
    source_url: Url
    statement_date: date
    predictions: list[PredictionInline] = Field(default_factory=list, max_length=20)


class StatementUpdate(BaseModel):
    text: Optional[req_str(5000)] = None
    source_url: Optional[Url] = None
    statement_date: Optional[date] = None


class StatementOut(StatementBrief):
    politician_id: int
    created_at: UTCDateTime
    predictions: list[PredictionBrief]


# --- Predykcje ----------------------------------------------------------------
class PredictionCreate(PredictionInline):
    statement_id: int


class PredictionUpdate(BaseModel):
    kind: Optional[Kind] = None
    claim: Optional[req_str(1000)] = None
    condition: opt_str(1000) = None
    topic: opt_str(100) = None
    deadline: Optional[date] = None


# --- Weryfikacje --------------------------------------------------------------
class VerificationOut(ORMModel):
    id: int
    prediction_id: int
    outcome: Outcome
    fulfilled_at: Optional[date]
    note: Optional[str]
    sources: list[str]
    verified_by: VerifiedBy
    verified_at: UTCDateTime

    @field_validator("sources", mode="before")
    @classmethod
    def _parse_sources(cls, value):
        if value is None:
            return []
        if isinstance(value, str):
            try:
                parsed = json.loads(value)
            except ValueError:
                return []
            return [str(x) for x in parsed] if isinstance(parsed, list) else []
        return value


class VerificationCreate(BaseModel):
    prediction_id: int
    outcome: Outcome
    fulfilled_at: Optional[date] = None
    note: opt_str(5000) = None
    sources: list[Url] = Field(default_factory=list, max_length=20)
    verified_by: VerifiedBy = "human"

    @model_validator(mode="after")
    def _fulfilled_only_when_true_or_partial(self):
        # odzwierciedla CHECK z schema_v2.sql – błąd 422 zamiast 500 z bazy
        if self.fulfilled_at is not None and self.outcome not in ("true", "partial"):
            raise ValueError("fulfilled_at można podać tylko dla wyniku „true” lub „partial”.")
        return self


class VerificationUpdate(BaseModel):
    """Korekta literówek. Zmiana oceny = nowy rekord (POST), nie edycja."""

    note: opt_str(5000) = None
    sources: Optional[list[Url]] = Field(default=None, max_length=20)


class PredictionOut(BaseModel):
    id: int
    statement_id: int
    kind: Kind
    claim: str
    condition: Optional[str]
    topic: Optional[str]
    deadline: Optional[date]
    created_at: UTCDateTime
    status: Status
    statement: StatementBrief
    politician: PoliticianBrief
    verification: Optional[VerificationOut]


class PredictionPage(BaseModel):
    items: list[PredictionOut]
    total: int
    limit: int
    offset: int


# --- Meta ---------------------------------------------------------------------
class MetaOut(BaseModel):
    parties: list[str]
    topics: list[str]
    statuses: list[Status]
    kinds: list[Kind]
