"""Seed z FIKCYJNYMI danymi: python -m app.seed

1. Dane przykładowe ze schema_v2.sql (jeśli tabela politicians jest pusta).
2. Dodatkowe fikcyjne rekordy, żeby UI miał co pokazać (idempotentnie).
Wszystkie osoby, cytaty i liczby są zmyślone.
"""
import json
from datetime import date

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import make_engine
from app.models import Politician, Prediction, Statement, Verification
from app.schema_sql import load_schema_parts, run_statements

D = date.fromisoformat

EXTRA = [
    {
        "politician": ("Piotr", "Wymyślony", "Partia A", "piotr-wymyslony"),
        "statements": [
            {
                "text": "Do końca 2025 roku bezrobocie spadnie poniżej 5%.",
                "url": "https://example.com/3",
                "date": "2025-03-05",
                "predictions": [
                    {
                        "kind": "prediction", "claim": "Bezrobocie poniżej 5%",
                        "condition": "Stopa bezrobocia rejestrowanego < 5% w grudniu 2025",
                        "topic": "gospodarka", "deadline": "2025-12-31",
                        "verifications": [
                            {"outcome": "true", "fulfilled_at": "2025-12-31", "by": "human",
                             "note": "Fikcyjne dane: stopa wyniosła 4,8%.", "sources": ["https://example.com/gus"]},
                        ],
                    }
                ],
            },
            {
                "text": "Nasza reforma skróci kolejki do specjalistów o połowę.",
                "url": "https://example.com/4",
                "date": "2025-06-12",
                "predictions": [
                    {
                        "kind": "promise", "claim": "Kolejki do specjalistów krótsze o 50%",
                        "condition": "Mediana czasu oczekiwania spada o co najmniej 50%",
                        "topic": "zdrowie", "deadline": "2026-01-01",
                        "verifications": [
                            {"outcome": "unverifiable", "by": "ai",
                             "note": "Brak wiarygodnych danych o czasach oczekiwania (dane fikcyjne)."},
                        ],
                    }
                ],
            },
        ],
    },
    {
        "politician": ("Maria", "Fikcyjna", "Partia C", "maria-fikcyjna"),
        "statements": [
            {
                "text": "Obiecuję: do połowy 2026 roku powstanie 100 tysięcy nowych mieszkań.",
                "url": "https://example.com/5",
                "date": "2024-09-01",
                "predictions": [
                    {
                        "kind": "promise", "claim": "100 tys. nowych mieszkań",
                        "condition": "Oddano >= 100 000 mieszkań w programie do 30.06.2026",
                        "topic": "mieszkalnictwo", "deadline": "2026-06-30",
                        "verifications": [  # historia: najpierw ocena AI, potem korekta człowieka
                            {"outcome": "unverifiable", "by": "ai", "note": "Dane niepełne (fikcyjne)."},
                            {"outcome": "partial", "by": "human", "fulfilled_at": "2026-06-30",
                             "note": "Oddano ok. 64 tys. mieszkań (dane fikcyjne).",
                             "sources": ["https://example.com/mieszkania"]},
                        ],
                    }
                ],
            },
            {
                "text": "Ceny prądu dla gospodarstw domowych nie wzrosną w 2025 roku.",
                "url": "https://example.com/6",
                "date": "2025-01-15",
                "predictions": [
                    {
                        "kind": "promise", "claim": "Brak podwyżek cen prądu w 2025",
                        "condition": "Taryfa dla gospodarstw domowych bez wzrostu w 2025",
                        "topic": "energetyka", "deadline": "2025-12-31",
                        "verifications": [
                            {"outcome": "false", "by": "human",
                             "note": "Taryfa wzrosła w trzecim kwartale (dane fikcyjne)."},
                        ],
                    }
                ],
            },
        ],
    },
    {
        "politician": ("Łukasz", "Zmyślony", "Partia B", "lukasz-zmyslony"),
        "statements": [
            {
                "text": "Za dwa lata ruszy pierwszy blok elektrowni jądrowej, a PKB urośnie w 2026 o ponad 4%.",
                "url": "https://example.com/7",
                "date": "2025-10-10",
                "predictions": [
                    {"kind": "prediction", "claim": "Start pierwszego bloku elektrowni jądrowej",
                     "condition": "Blok przyłączony do sieci do końca 2027", "topic": "energetyka",
                     "deadline": "2027-12-31", "verifications": []},
                    {"kind": "prediction", "claim": "Wzrost PKB w 2026 powyżej 4%",
                     "condition": "Wzrost PKB za 2026 > 4,0%", "topic": "gospodarka",
                     "deadline": "2027-03-31", "verifications": []},
                ],
            },
        ],
    },
]


def seed(session: Session) -> None:
    for first, last, party, slug in (e["politician"] for e in EXTRA):
        if session.scalar(select(Politician.id).where(Politician.slug == slug)):
            continue
        entry = next(e for e in EXTRA if e["politician"][3] == slug)
        politician = Politician(first_name=first, last_name=last, party=party, slug=slug)
        for s in entry["statements"]:
            statement = Statement(text=s["text"], source_url=s["url"], statement_date=D(s["date"]))
            for p in s["predictions"]:
                prediction = Prediction(
                    kind=p["kind"], claim=p["claim"], condition=p["condition"], topic=p["topic"],
                    deadline=D(p["deadline"]) if p.get("deadline") else None,
                )
                for v in p["verifications"]:
                    prediction.verifications.append(
                        Verification(
                            outcome=v["outcome"], verified_by=v["by"], note=v.get("note"),
                            fulfilled_at=D(v["fulfilled_at"]) if v.get("fulfilled_at") else None,
                            sources=json.dumps(v["sources"]) if v.get("sources") else None,
                        )
                    )
                statement.predictions.append(prediction)
            politician.statements.append(statement)
        session.add(politician)
    session.commit()


def main() -> None:
    engine = make_engine(get_settings().database_url)
    with engine.begin() as conn:
        empty = conn.exec_driver_sql("SELECT COUNT(*) FROM politicians").scalar() == 0
        if empty:
            _ddl, sample = load_schema_parts()
            run_statements(conn, sample, engine.dialect.name)
    with Session(engine) as session:
        seed(session)
    print("Seed zakończony (dane fikcyjne).")


if __name__ == "__main__":
    main()
