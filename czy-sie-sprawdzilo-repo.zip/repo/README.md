# Czy się sprawdziło?

MVP serwisu z bazą wypowiedzi i predykcji polityków: wyszukiwarka, filtry, statystyka trafności,
historia ocen. Weryfikacja przez AI zostanie dodana później (pole `verified_by = 'ai'` jest już w schemacie).

> **Dane w seedzie są fikcyjne.**

## Struktura

```
backend/   FastAPI + SQLAlchemy + Alembic (SQLite; Postgres przez DATABASE_URL)
  schema/schema_v2.sql   źródło prawdy schematu – NIE jest modyfikowany
  app/                   config, db, models, schemas, queries, routers/, seed
  alembic/               migracja 0001 wykonuje DDL ze schema_v2.sql
  tests/                 pytest
frontend/  React + TypeScript (Vite), PWA
  src/api/     klient REST (http.ts, client.ts) + typy z OpenAPI (schema.d.ts)
  src/lib/     czysta logika: formatowanie, statystyki, filtry<->URL, walidacja
  src/hooks/   hooki danych i formularza (bez widoków)
  src/ui/, src/pages/   widoki – jedyna warstwa zależna od przeglądarki
```

## Uruchomienie lokalne

Wymagane: Python 3.11+, Node 18+.

### 1. Backend
```bash
cd backend
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt
alembic upgrade head          # tworzy czy_sie_sprawdzilo.db ze schema_v2.sql
python -m app.seed            # fikcyjne dane (opcjonalnie)
uvicorn app.main:app --reload --port 8000
```
Dokumentacja API: http://localhost:8000/api/v1/docs · schemat: `/api/v1/openapi.json`

### 2. Frontend (drugi terminal)
```bash
cd frontend
npm install
npm run dev                   # http://localhost:5173 (proxy /api -> :8000)
```

### 3. Testy backendu
```bash
cd backend && pytest
```

## Konfiguracja
| Zmienna | Gdzie | Domyślnie |
|---|---|---|
| `DATABASE_URL` | backend | `sqlite:///./czy_sie_sprawdzilo.db` (ścieżka względem katalogu `backend`) |
| `CORS_ORIGINS` | backend | `http://localhost:5173,http://127.0.0.1:5173` |
| `VITE_API_URL` | frontend | `/api/v1` |

**SQLite i klucze obce:** działają tylko po `PRAGMA foreign_keys = ON` na *każdym* połączeniu –
robi to `app/db.py` (listener `connect`), a testy to sprawdzają.

**Postgres (best-effort):** `pip install "psycopg[binary]"`, ustaw
`DATABASE_URL=postgresql+psycopg://user:haslo@host/db`, `alembic upgrade head`.
Migracja tłumaczy DDL według uwag z nagłówka `schema_v2.sql` (IDENTITY, TIMESTAMPTZ, bez PRAGMA).
Ścieżka Postgres nie była testowana.

## API (`/api/v1`)
- `GET /predictions` – filtry: `status, party, topic, politician_id, kind, q, date_from, date_to`;
  `sort` (`statement_date|deadline|verified_at|created_at`), `order`, `limit` (≤100), `offset`;
  odpowiedź: `{items, total, limit, offset}`; status z widoku `prediction_status`.
- `GET /predictions/{id}`, `GET /predictions/{id}/verifications` (historia ocen)
- `GET /politicians?q=`, `GET /politicians/{slug}` – ze statystyką `(true + 0.5·partial) / rozstrzygnięte`
  (rozstrzygnięte = true + partial + false; brak rozstrzygniętych → `accuracy: null`)
- `GET /meta` – partie, tematy, statusy, rodzaje
- `POST/PATCH` `/politicians`, `/statements` (z zagnieżdżonymi predykcjami), `/predictions`, `/verifications`
- `POST /verifications` **zawsze dodaje rekord**; `PATCH /verifications/{id}` poprawia tylko
  `note`/`sources` (zmiana oceny = nowy POST).
- Zapisy mają zależność `authorize` (`app/deps.py`) – dziś nic nie sprawdza, to miejsce na token.

```bash
curl -X POST localhost:8000/api/v1/verifications -H 'Content-Type: application/json' \
  -d '{"prediction_id":2,"outcome":"true","fulfilled_at":"2026-06-01","note":"Kurs 3,95","sources":["https://example.com"]}'
```

## Typy z OpenAPI
`frontend/src/api/schema.d.ts` jest początkowym, ręcznie przygotowanym odpowiednikiem. Przy działającym
backendzie wygeneruj prawdziwy: `npm run gen:api` (nazwy schematów się nie zmieniają). Po każdej zmianie API powtórz.

## PWA
`vite-plugin-pwa` (manifest + service worker z cache powłoki aplikacji; `/api` nigdy nie jest cache'owane).
Ikony: `frontend/public/icons/` (192, 512, maskable, apple-touch). Sprawdź: `npm run build && npm run preview`.

## Plan przejścia na React Native / Expo
Logika jest rozdzielona od widoków właśnie po to:
1. **Wspólny pakiet:** przenieś `src/api`, `src/lib`, `src/hooks` do `packages/core` (npm workspaces);
   web i aplikacja importują ten sam kod.
2. **Jedyna zmiana w rdzeniu:** `api/config.ts` (`import.meta.env.VITE_API_URL` →
   `process.env.EXPO_PUBLIC_API_URL`; w aplikacji pełny adres, nie `/api/v1`).
   `fetch`, `URLSearchParams`, `AbortController` działają w RN. `Intl` w `format.ts` – na Androidzie
   (Hermes) sprawdź lokalizację `pl-PL`, ewentualnie dodaj polyfill.
3. **Widoki od nowa** (`src/ui`, `src/pages`): `div/p/select` → `View/Text/Pressable/Picker`,
   `PredictionCard` i `FilterBar` mają już czyste propsy. Style: `StyleSheet` + tokeny z `styles.css`.
4. **Nawigacja:** `react-router` → `expo-router` (trasy: `/`, `/politycy`, `/politycy/[slug]`, `/dodaj`);
   `useSearchParams` zastąp `useLocalSearchParams` – `parseFilters/serializeFilters` zostają.
5. **Motyw:** `ui/theme.ts` → `useColorScheme()` + `AsyncStorage`. Linki zewnętrzne: `Linking.openURL`.
6. **Autoryzacja (później):** `setAuthToken` w `api/http.ts` + `expo-secure-store`.

## Znane ograniczenia MVP
- Brak uwierzytelniania i usuwania rekordów; zapisy są otwarte.
- Wyszukiwanie to `LIKE` (bez ignorowania polskich znaków diakrytycznych: „lukasz” nie znajdzie „Łukasz”).
- Zmiana daty wypowiedzi (PATCH) nie weryfikuje ponownie terminów jej predykcji.
